## -----------------------------------------------------------------------------------------------
setGeneric(name = "contrast_blur_img",
           def = function(obj, size, sigma,...) return(NULL)
)

setMethod(f = "contrast_blur_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, size = round(510/10), sigma = 1) {
            contrast_blur_img.LoST(obj,size = size, sigma = sigma)
          })


contrast_blur_img.LoST <- function(obj, size = round(510/10), sigma = 1){
  # normalize and blur and image
  w <- EBImage::makeBrush(size = size, shape = 'gaussian', sigma = sigma)
  for (i in 1:length(obj@img_process)){
    # browser()

    obj@img_process[[i]] <- EBImage::normalize(obj@img_process[[i]])

    obj@img_process[[i]][obj@trim[[i]]] = 0
    ## restore the trimmed edge to 0 for filtering/blurring, put it to NA afterwards
    obj@img_process[[i]] <- EBImage::filter2(obj@img_process[[i]], w)
    obj@img_process[[i]][obj@trim[[i]]] = NA

  }
  return(obj)
}

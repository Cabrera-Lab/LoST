## -----------------------------------------------------------------------------------------------
setMethod(f = "plot",
          signature = signature(x = "LoST",
                                y = "missing"),

          definition = function(x,
                                img_num = NA,
                                overlay = FALSE,
                                plot_plate = FALSE,
                                plate_name = NA) {
            plot_img.LoST(obj = x,
                          img_num = img_num,
                          overlay = overlay,
                          plot_plate = plot_plate,
                          plate_name = plate_name)
          })


plot_img.LoST <- function(obj,
                          img_num = NA,
                          overlay = FALSE,
                          plot_plate = FALSE,
                          plate_name = NA) {
  ## check parameter
  if (!is.na(img_num) & !(img_num %in% (1:length(obj@raw_img)))){
    stop("img_num does not exist.")
  }
  if (!is.na(plate_name) & !(plate_name %in% unique(obj@meta$plate))){
    stop("plate_name does not exist.")
  }

  if (plot_plate == TRUE) {
    if (nrow(obj@meta) == 0) {
      warning("No metadata found in the LoST object. Add the data first with get_meta function.")
    } else {
      if (is.na(plate_name)){
        ###### for displaying all plate name #######
        if (!is.na(img_num)){
          stop("plate_name has to be specified when plot_plate is TRUE and img_num is specified.")
        }

        old_mar <- par()$mar

        # loop through plates, create 1 image per plate
        temp_plate <- split(obj@meta,f = obj@meta$plate)
        for (j in 1:length(temp_plate)){
          temp_plate[[j]] <- temp_plate[[j]][order(temp_plate[[j]]$well_row,temp_plate[[j]]$well_column),]

          temp_subplate <- split(temp_plate[[j]],temp_plate[[j]]$well_row)

          layout0 <- matrix(0,nrow = length(unique(temp_plate[[j]]$well_row)),ncol = max(temp_plate[[j]]$well_column))  ## +1 because of the col.name and row.name
          for (k in 1:length(temp_subplate)){
            layout0[k,temp_subplate[[k]]$well_column] = 1
          }
          nrow_layout <- nrow(layout0)
          ncol_layout <- ncol(layout0)
          layout0 <- as.vector(t(layout0))
          layout0[which(layout0>0)] = seq(1:length(which(layout0>0)))
          layout0 <- matrix(layout0,nrow = nrow_layout,ncol = ncol_layout,byrow = T)

          layout0 <- cbind(NA,layout0)
          layout0 <- rbind(NA,layout0)
          layout0[1,] <- (max(layout0,na.rm = T)+1):(max(layout0,na.rm = T)+1+ncol_layout) ## col name
          layout0[-1,1] <- (max(layout0,na.rm = T)+1):(max(layout0,na.rm = T)+1+nrow_layout-1) ## row name

          layout(layout0)
          par(mar=c(0,0,0,0))

          for (i in 1:nrow(temp_plate[[j]])) {
            EBImage::display(obj@raw_img[[match(temp_plate[[j]]$image_name[i],names(obj@raw_img))]],
                             method = "raster")
            if (overlay == TRUE){
              if (length(obj@spot_pos) == 0) {
                warning("The main algorithm was not run. No clustering data yet exists to overlay. Or No cluster was found.")
              } else {
                temp0 <- match(temp_plate[[j]]$image_name[i],names(obj@raw_img)) ## find the corresponding img_num
                points(obj@spot_pos[[temp0]],
                       col = 2,pch=16)
                if (length(obj@edge_iso_clus3[[temp0]])==0){
                  warning("No cluster was found.")
                } else{
                  for(iii in 1:length(obj@edge_iso_clus3[[temp0]])){
                    points(obj@edge_iso_clus3[[temp0]][[iii]],cex=0.05,col=2)
                  }
                }

              }
            }

          }
          ## plot the plate name
          plot(1, type="n", xlab="", ylab="",xaxt = 'n',yaxt='n',axes=F) ## blank plot
          text(1,1,paste0("Plate",names(temp_plate)[j],sep=""),cex=1.5)

          ## plot the col name
          for (ii in (1:ncol_layout)){
            # plot(1, type="n", xlab="", ylab="", xlim=c(0, 1), ylim=c(0, 1),xaxt = 'n',yaxt='n',axes=F,main=ii,cex.main=2)
            plot(1, type="n", xlab="", ylab="", xaxt = 'n',yaxt='n',axes=F)
            text(1,1,ii,cex=1.5)
          }

          ## plot row name
          for (jj in (1:nrow_layout)){
            # plot(1, type="n", xlab="", ylab="", xlim=c(0, 1), ylim=c(0, 1),xaxt = 'n',yaxt='n',axes=F,main=LETTERS[jj],cex.main=2)
            plot(1, type="n", xlab="", ylab="",xaxt = 'n',yaxt='n',axes=F)
            row_letter0 = match(temp_plate[[j]]$well_row[1],LETTERS)
            text(1,1,LETTERS[row_letter0-1+jj],cex=1.5)
          }
        }
      } else {
        ###### for displaying particular plate name #######
        old_mar <- par()$mar

        temp_plate <- split(obj@meta,f = obj@meta$plate)
        j = which(names(temp_plate)==plate_name)  ## focus on one plate only

        temp_plate[[j]] <- temp_plate[[j]][order(temp_plate[[j]]$well_row,temp_plate[[j]]$well_column),]
        temp_subplate <- split(temp_plate[[j]],temp_plate[[j]]$well_row)

        layout0 <- matrix(0,nrow = length(unique(temp_plate[[j]]$well_row)),ncol = max(temp_plate[[j]]$well_column))  ## +1 because of the col.name and row.name
        for (k in 1:length(temp_subplate)){
          layout0[k,temp_subplate[[k]]$well_column] = 1
        }
        nrow_layout <- nrow(layout0)
        ncol_layout <- ncol(layout0)
        layout0 <- as.vector(t(layout0))
        layout0[which(layout0>0)] = seq(1:length(which(layout0>0)))
        layout0 <- matrix(layout0,nrow = nrow_layout,ncol = ncol_layout,byrow = T)

        layout0 <- cbind(NA,layout0)
        layout0 <- rbind(NA,layout0)
        layout0[1,] <- (max(layout0,na.rm = T)+1):(max(layout0,na.rm = T)+1+ncol_layout) ## col name
        layout0[-1,1] <- (max(layout0,na.rm = T)+1):(max(layout0,na.rm = T)+1+nrow_layout-1) ## row name

        layout(layout0)
        par(mar=c(0,0,0,0))

        # browser()
        if (!is.na(img_num)){
          for (i in 1:nrow(temp_plate[[j]])) {
            if (names(obj@raw_img)[img_num] == temp_plate[[j]]$image_name[i]){
              EBImage::display(obj@raw_img[[img_num]],
                               method = "raster")
              if (overlay == TRUE){
                if (length(obj@spot_pos) == 0) {
                  warning("The main algorithm was not run. No clustering data yet exists to overlay. Or No cluster was found.")
                } else {
                  temp0 <- match(temp_plate[[j]]$image_name[i],names(obj@raw_img)) ## find the corresponding img_num
                  points(obj@spot_pos[[temp0]],
                         col = 2,pch=16)
                  if (length(obj@edge_iso_clus3[[temp0]])==0){
                    warning("No cluster was found.")
                  } else{
                    for(iii in 1:length(obj@edge_iso_clus3[[temp0]])){
                      points(obj@edge_iso_clus3[[temp0]][[iii]],cex=0.05,col=2)
                    }
                  }

                }
              }
            } else {
              plot(1, type="n", xlab="", ylab="",xaxt = 'n',yaxt='n',axes=F) ## blank plot
            }
          }
        } else{
          for (i in 1:nrow(temp_plate[[j]])) {

            EBImage::display(obj@raw_img[[match(temp_plate[[j]]$image_name[i],names(obj@raw_img))]],
                             method = "raster")
            if (overlay == TRUE){
              if (length(obj@spot_pos) == 0) {
                warning("The main algorithm was not run. No clustering data yet exists to overlay. Or No cluster was found.")
              } else {
                temp0 <- match(temp_plate[[j]]$image_name[i],names(obj@raw_img)) ## find the corresponding img_num
                points(obj@spot_pos[[temp0]],
                       col = 2,pch=16)
                if (length(obj@edge_iso_clus3[[temp0]])==0){
                  warning("No cluster was found.")
                } else{
                  for(iii in 1:length(obj@edge_iso_clus3[[temp0]])){
                    points(obj@edge_iso_clus3[[temp0]][[iii]],cex=0.05,col=2)
                  }
                }
              }
            }
          }
        }
        ## plot the plate name
        plot(1, type="n", xlab="", ylab="",xaxt = 'n',yaxt='n',axes=F) ## blank plot
        text(1,1,paste0("Plate",names(temp_plate)[j],sep=""),cex=1.5)

        ## plot the col name
        for (ii in (1:ncol_layout)){
          # plot(1, type="n", xlab="", ylab="", xlim=c(0, 1), ylim=c(0, 1),xaxt = 'n',yaxt='n',axes=F,main=ii,cex.main=2)
          plot(1, type="n", xlab="", ylab="", xaxt = 'n',yaxt='n',axes=F)
          text(1,1,ii,cex=1.5)
        }

        ## plot row name
        for (jj in (1:nrow_layout)){
          # plot(1, type="n", xlab="", ylab="", xlim=c(0, 1), ylim=c(0, 1),xaxt = 'n',yaxt='n',axes=F,main=LETTERS[jj],cex.main=2)
          plot(1, type="n", xlab="", ylab="",xaxt = 'n',yaxt='n',axes=F)
          row_letter0 = match(temp_plate[[j]]$well_row[1],LETTERS)
          text(1,1,LETTERS[row_letter0-1+jj],cex=1.5)
        }
      }
      ## reset the plot space
      # suppressWarnings(par(old_par))
      suppressWarnings(par(mfrow=c(1,1),mar=old_mar))


    }
  } else {
    if (is.na(img_num)){
      for (i in 1:length(obj@raw_img)) {
        EBImage::display(obj@raw_img[[i]],
                         method = "raster")
        if (overlay == TRUE){
          if (length(obj@spot_pos) == 0) {
            warning("The main algorithm was not run. No clustering data yet exists to overlay. Or No cluster was found.")
          } else {
            points(obj@spot_pos[[i]],
                   col = 2,pch=16)

            if (length(obj@edge_iso_clus3[[i]])==0){
              warning("No cluster was found.")
            } else{
              for(iii in 1:length(obj@edge_iso_clus3[[i]])){
                points(obj@edge_iso_clus3[[i]][[iii]],cex=0.05,col=2)
              }
            }

          }
        }
      }
    } else{
      EBImage::display(obj@raw_img[[img_num]],
                       method = "raster")
      if (overlay == TRUE){
        if (length(obj@spot_pos) == 0) {
          warning("The main algorithm was not run. No clustering data yet exists to overlay. Or No cluster was found.")
        } else {
          points(obj@spot_pos[[img_num]],
                 col = 2,pch=16)

          if (length(obj@edge_iso_clus3[[img_num]])==0){
            warning("No cluster was found.")
          } else{
            for(iii in 1:length(obj@edge_iso_clus3[[img_num]])){
              points(obj@edge_iso_clus3[[img_num]][[iii]],cex=0.05,col=2)
            }
          }


        }
      }
    }
  }
}

## -----------------------------------------------------------------------------------------------
setGeneric(name = "clus_break_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "clus_break_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            clus_break_img.LoST(obj)
          })


clus_break_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@completed[[i]])!=0){
      next
    }
    if (length(obj@res[[i]]$watershed_group)==0){
      obj@iso_clus[[i]] = list()
      next
    }
    obj@iso_clus[[i]] = list()
    for (j in 1:length(obj@res[[i]]$watershed_group)){
      obj@iso_clus[[i]][[j]] <- iso_clus_img.LoST(obj@img_process[[i]], obj@img[[i]], obj@res[[i]]$watershed_group[j])
    }
  }
  return(obj)
}


iso_clus_img.LoST <- function(obj, obj2, ii){  ## obj can be the image after watershed, obj2 is the original image retaining the intensity
  set2 <- which(obj==ii,arr.ind = T)
  save_pos0 = set2
  save_intensity0 = obj2[set2]
  return(list(save_pos0=save_pos0,save_intensity0=save_intensity0))
}

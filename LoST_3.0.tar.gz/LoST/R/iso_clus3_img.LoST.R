## -----------------------------------------------------------------------------------------------
setGeneric(name = "iso_clus3_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "iso_clus3_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, itmax = 300000, sub_portion = 10, GMmodel = c("EII","VII"), seed_num = 1992) {
            iso_clus3_img.LoST(obj,
                               itmax = itmax,
                               sub_portion = sub_portion,
                               GMmodel = GMmodel,
                               seed_num = seed_num)
          })


iso_clus3_img.LoST <- function(obj, itmax=3, sub_portion=3, GMmodel = "EII", seed_num=1992){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    record0 = length(obj@clus_count[[i]])   ## record how many clusters in the beginning so that we can trace how many new clusters are identified through GMM
    obj@is_GMM[[i]] = list()
    for (j in 1:length(obj@clus_count[[i]])){
      obj@is_GMM[[i]][[j]] = 0
      if (obj@clus_count[[i]][[j]][1]!=1){
        record0 = record0 - 1
        ### GMM
        set.seed(seed_num)
        if (is.na(sub_portion)){
          mod_gmm0 <- mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = obj@clus_count[[i]][[j]][1],modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F)
        } else if (nrow(obj@clus_multilayer[[i]][[j]])/sub_portion <= 10){
          mod_gmm0 <- mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = obj@clus_count[[i]][[j]][1],modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F)
        } else{
          mod_gmm0 <- mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = obj@clus_count[[i]][[j]][1],modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F,initialization = list(subset=sample(1:nrow(obj@clus_multilayer[[i]][[j]]),size = round(nrow(obj@clus_multilayer[[i]][[j]])/sub_portion))))
        }

        temp_center0 = list()
        temp0 = list()
        for (k in unique(mod_gmm0$classification)){
          save_pos0_gmm <- obj@clus_multilayer[[i]][[j]][mod_gmm0$classification==k,]
          save_intensity0_gmm = obj@img[[i]][save_pos0_gmm]
          temp0[[k]] = list(save_pos0 = save_pos0_gmm, save_intensity0 = save_intensity0_gmm)
          temp_center0[[k]] = data.frame(t(mod_gmm0$parameters$mean[,k]))
        }
        obj@iso_clus[[i]][[j]]=list()
        obj@iso_clus[[i]] <- append(obj@iso_clus[[i]],temp0)

        obj@clus_center[[i]][[j]]=list()
        obj@clus_center[[i]] <- append(obj@clus_center[[i]],temp_center0)

      }
    }
    obj@iso_clus[[i]] = Filter(length, obj@iso_clus[[i]])  ## filter the list with zero length
    obj@clus_center[[i]] = Filter(length, obj@clus_center[[i]])
    for (kk in (record0+1):length(obj@iso_clus[[i]])){
      obj@is_GMM[[i]][[kk]] = 1
    }
  }
  return(obj)
}



f1_iso_clus3_img.LoST <- function(j, obj=obj, i=i,itmax=itmax,sub_portion=sub_portion,GMmodel=GMmodel,seed_num=seed_num,e0=e0, record0 = record0,...){
  if (j == 1){
    temp_iso_clus = obj@iso_clus[[i]]
    temp_clus_center = obj@clus_center[[i]]
    temp_is_GMM = obj@is_GMM[[i]]
  } else{
    temp_iso_clus = e0$temp_iso_clus
    temp_clus_center = e0$temp_clus_center
    temp_is_GMM = e0$temp_is_GMM
  }
  temp_is_GMM[[j]] = 0
  if (length(obj@clus_correct[[i]])==0){

  } else if (obj@clus_correct[[i]][[j]]==1){
    record0 = record0 - 1
    ### GMM
    set.seed(seed_num)
    if (is.na(sub_portion)){
      mod_gmm0 <- mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = obj@clus_count3[[i]][[j]][1],modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F)
    } else {
      mod_gmm0 <- mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = obj@clus_count3[[i]][[j]][1],modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F,initialization = list(subset=sample(1:nrow(obj@clus_multilayer[[i]][[j]]),size = nrow(obj@clus_multilayer[[i]][[j]])/sub_portion)))
    }

    temp_center0 = list()
    temp0 = list()
    for (k in unique(mod_gmm0$classification)){
      save_pos0_gmm <- obj@clus_multilayer[[i]][[j]][mod_gmm0$classification==k,]
      save_intensity0_gmm = obj@img[[i]][save_pos0_gmm]
      temp0[[k]] = list(save_pos0 = save_pos0_gmm, save_intensity0 = save_intensity0_gmm)
      temp_center0[[k]] = data.frame(t(mod_gmm0$parameters$mean[,k]))
    }
    temp_iso_clus[[j]]=list()
    temp_iso_clus <- append(temp_iso_clus,temp0)
    # print(paste0("iso3 ",i," ",j))

    temp_clus_center[[j]]=list()
    temp_clus_center <- append(temp_clus_center,temp_center0)

  }
  assign("temp_iso_clus", temp_iso_clus,envir = e0)
  assign("temp_clus_center", temp_clus_center,envir = e0)
  assign("temp_is_GMM", temp_is_GMM,envir = e0)
  assign("record0",record0,envir = e0)
  return(NULL)
}


f2_iso_clus3_img.LoST <- function(i, obj=obj,itmax=itmax,sub_portion=sub_portion,GMmodel=GMmodel, seed_num=seed_num){
  if (length(obj@iso_clus[[i]])==0){
    # next
    return()
  }
  record0 = length(obj@clus_count3[[i]])   ## record how many clusters in the beginning so that we can trace how many new clusters are identified through GMM
  obj@is_GMM[[i]] = list()

  e0 <- new.env()
  invisible(lapply(1:length(obj@clus_count3[[i]]), f1_iso_clus3_img.LoST,obj=obj,i=i,itmax=itmax,sub_portion=sub_portion,GMmodel=GMmodel,seed_num=seed_num,e0=e0, record0 = record0))

  e0$temp_iso_clus = Filter(length, e0$temp_iso_clus)  ## filter the list with zero length
  e0$temp_clus_center = Filter(length, e0$temp_clus_center)
  if (e0$record0!=record0){
    for (kk in (e0$record0+1):length(e0$temp_iso_clus)){
      e0$temp_is_GMM[[kk]] = 1
    }
  }
  return(list(iso_clus = e0$temp_iso_clus, clus_center=e0$temp_clus_center, is_GMM=e0$temp_is_GMM))
}



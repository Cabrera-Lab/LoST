## -----------------------------------------------------------------------------------------------
setGeneric(name = "stratify_img",
           def = function(obj, skewness0, ...) return(NULL)
)

setMethod(f = "stratify_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, skewness0 = 0.5) {
            stratify_img.LoST(obj, skewness0 = skewness0)
          })


stratify_img.LoST <- function(obj, skewness0 = 0.5){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@clus_multilayer[[i]] = list()
    obj@clus_multilayer[[i]] <- lapply(1:length(obj@is_one_tree[[i]]),FUN = f1_stratify_img.LoST,obj=obj,i=i,skewness0 = skewness0)
  }
  return(obj)
}

f1_stratify_img.LoST <- function(j, obj = obj, i=i, skewness0 = skewness0){
  width0 = dim(obj@img[[i]])[1]
  height0 = dim(obj@img[[i]])[2]
  reconstruct_img <- matrix(data = 0,nrow = width0,ncol = height0)
  reconstruct_img[obj@iso_clus[[i]][[j]]$save_pos0] = obj@iso_clus[[i]][[j]]$save_intensity0

  set1 <- which(reconstruct_img==0,arr.ind = T)
  reconstruct_img[set1]=NA  ## to temporarily put the background pixels (=0) to NA

  set2 = NULL
  if (abs(round(obj@skewness[[i]][[j]],digits = 2))>skewness0){
    for (jj in 1:2){
      set3 <- which(reconstruct_img>=quantile(reconstruct_img,probs = c(0.6,0.8),na.rm = T)[jj],arr.ind = T)
      set2 <- rbind(set2,set3)   ## set3 is the cluster with different intensity thresholds to reveal the intensity characteristic
    }
  } else {
    for (jj in 1:4){
      set3 <- which(reconstruct_img>=quantile(reconstruct_img,probs = c(0.2,0.4,0.6,0.8),na.rm = T)[jj],arr.ind = T)
      set2 <- rbind(set2,set3)   ## set3 is the cluster with different intensity thresholds to reveal the intensity characteristic
    }
  }
  return(set2)
}


f2_stratify_img.LoST <- function(i, obj = obj, skewness0 = skewness0){
  if (length(obj@iso_clus[[i]])==0){
    # next
    return()
  }

  temp0 <- lapply(1:length(obj@is_one_tree[[i]]),FUN = f1_stratify_img.LoST,obj=obj,i=i,skewness0 = skewness0)
  return(temp0)
}




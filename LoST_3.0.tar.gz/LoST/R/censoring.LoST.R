## -----------------------------------------------------------------------------------------------
setGeneric(name = "censoring",
           def = function(obj,res0_sim, ...) return(NULL)
)

setMethod(f = "censoring",
          signature = signature(obj = "LoST"),
          definition = function(obj,res0_sim) {
            censoring.LoST(obj,res0_sim=res0_sim)
          })

censoring.LoST <- function(obj,res0_sim){
  temp0 <- res0_sim$`coverage 97.5%`
  obj@final_res$new_censored <- (obj@final_res$px_ratio >= temp0)*1
  obj@final_res$new_censored[is.na(obj@final_res$new_censored)] <- 0
  obj@final_res$censored <- obj@final_res$censored + obj@final_res$new_censored

  return(obj)
}

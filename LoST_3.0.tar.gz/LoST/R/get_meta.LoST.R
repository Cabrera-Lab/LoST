## -----------------------------------------------------------------------------------------------
setGeneric(name = "get_meta",
           def = function(obj, file,...) return(NULL)
)

setMethod(f = "get_meta",
          signature = signature(obj = "LoST"),
          definition = function(obj, file) {
            get_meta.LoST(obj,file=file)
          })



get_meta.LoST <- function(obj,
                          file){
  obj@meta <- fread(file = file)
  return(obj)

}


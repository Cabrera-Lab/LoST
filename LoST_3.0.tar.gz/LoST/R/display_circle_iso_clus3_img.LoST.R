## -----------------------------------------------------------------------------------------------
setGeneric(name = "display_circle_iso_clus3_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "display_circle_iso_clus3_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            display_circle_iso_clus3_img.LoST(obj)
          })


display_circle_iso_clus3_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    width0 = dim(obj@img[[i]])[1]
    height0 = dim(obj@img[[i]])[2]

    for (j in 1:length(obj@iso_clus[[i]])){
      center0 = round(obj@clus_center[[i]][[j]])

      if (is.na(obj@radius3_var[[i]][[j]]) & is.na(obj@radius3_cv[[i]][[j]])){
        ## only 2 (or 3) pixels for this cluster, no need to do anything to recreate the circle
        next
      }

      r0 = max(obj@radius3[[i]][[j]])
      if (r0==0){
        ## only one pixel for this cluster, no need to do anything to recreate the circle
        next
      }

      ## create circle
      d2 = r0*2
      m11 <- matrix(rep(((1:d2 - d2/2))^2, d2),
                    ncol = d2,
                    byrow = TRUE)
      mmm <- sqrt(m11 + t(m11))
      set00 <- which(mmm <= d2/2, arr.ind = TRUE)
      set00 = set00 - ceiling(d2/2)  ## align the small circle to be centered at origin, i.e., (0,0) , ceiling() is for odd d2

      set00[,1] = set00[,1] + center0$row
      set00[,2] = set00[,2] + center0$col
      obj@iso_clus[[i]][[j]] = list(save_pos0 = set00, save_intensity0 = rep(1,nrow(set00)))

    }
  }
  return(obj)
}

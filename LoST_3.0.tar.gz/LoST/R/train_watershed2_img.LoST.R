train_watershed2_img.LoST <- function(obj, tol0){
  # browser()
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }

    count0 = 1
    for (j in 1:length(obj@radius3_var[[i]])){
      if (is.na(obj@radius3_var[[i]][[j]])){
        next
      }

      temp0 = obj@is_GMM[[i]]
      if (temp0$is.one[j]!=1){
        y <- EBImage::normalize(EBImage::watershed(obj@iso_clus3[[i]][[j]],tolerance = tol0)) ## 0.15
        for (jj in unique(as.numeric(y))){
          if (jj==0) next  ## background intensity
          set1 <- which(y == jj,arr.ind = T)
          obj@img_process[[i]][set1] = jj+count0    ## embed the second-stage watershed into "@img_process"
        }
        count0 = count0 + 1

      }
    }
    obj@img_process[[i]] <- EBImage::normalize(obj@img_process[[i]])
  }
  return(obj)
}




#gen_rep: function to generate simulated dilution serial count data
#lambda: true number of particles in the neat sample
#p: dilution proportion, i.e, 1/dilution factor
#s: sampling proportion from tubes to wells for each replica. 
#   If there are multiple replicates, it needs to be a vector with elements corresponding to each replicate.
#N: number of dilutions
#m: number of replicates in the experiment
gen_rep <- function(lambda,p,s,N,m){
  
  if(lambda %% 1 != 0 | lambda <= 0){
    stop("lambda should be a positive integer")
  }
  if(p <=0 | p >=1){
    stop("p should be between 0 and 1")
  }
  if(sum(s <= 0) > 0 | sum(s >= 1) > 0){
    stop("sampling proportions should be between 0 and 1")
  }
  if(N %% 1 != 0 | N <= 0){
    stop("N should be a positive integer")
  }
  if(m %% 1 != 0 | m <= 0){
    stop("m should be a positive integer")
  }
  if(length(s) != m){
    stop("The length of s doesn't equal to m. The sampling proportions for each replicate should be provided.")
  }
  
  ydata = rbinom(1,lambda,p)
  for (i in 1:(N-1)) {ydata = c(ydata, rbinom(1,ydata[i],p))}
  xdata = NULL
  for (i in 1:N){
    x = rmultinom(1,ydata[i],c(s,1-sum(s)))
    xdata = cbind(xdata,x[1:m])
  }
  return(xdata)
}

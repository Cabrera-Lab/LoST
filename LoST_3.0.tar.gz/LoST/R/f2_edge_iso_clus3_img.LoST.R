f2_edge_iso_clus3_img.LoST <- function(i, obj = obj){
  if (length(obj@iso_clus[[i]])==0){
    # next
    return()
  }
  return(lapply(1:length(obj@iso_clus[[i]]),f1_edge_iso_clus3_img.LoST,obj = obj, i=i))
}

f1_edge_iso_clus3_img.LoST <- function(j, obj = obj,i=i){
  # set1 <- which(obj@iso_clus3[[i]][[j]]>0,arr.ind = T)
  if (length(dim(obj@iso_clus[[i]][[j]]$save_pos0)[1])==0){
    temp0 = data.frame(t(obj@iso_clus[[i]][[j]]$save_pos0))
    names(temp0) = c("row", "col")
    return(temp0)
  } else {
    temp0 <- data.frame(concaveman::concaveman(obj@iso_clus[[i]][[j]]$save_pos0,concavity = 1))
    names(temp0) = c("row", "col")
    return(temp0)
  }

}

## -----------------------------------------------------------------------------------------------
setGeneric(name = "prep_series",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "prep_series",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            prep_series.LoST(obj)
          })


prep_series.LoST <- function(obj){
  split_df <- split(obj@final_res,obj@final_res$plate)

  ## prepare the output for dilution series
  for (j in as.numeric(as.factor(unique(obj@final_res$plate)))){
    ## separate the case of different plate
    temp_df <- split_df[match(unique(obj@final_res$plate)[j],names(split_df))][[1]]

    ## initiate a matrix for dilution series output
    obj@series[[j]] <- matrix(NA,nrow = max(match(unique(temp_df$well_row),LETTERS)),ncol = max(temp_df$well_column))
    row.names(obj@series[[j]]) <- LETTERS[1:nrow(obj@series[[j]])]
    colnames(obj@series[[j]]) <- seq(1,ncol(obj@series[[j]]),by = 1)

    ## insert the counts into correct position of the dilution series
    for (ii in 1:nrow(temp_df)){
      obj@series[[j]][temp_df$well_row[ii],temp_df$well_column[ii]] = temp_df$new_count[ii]
    }
  }
  names(obj@series) <- paste("Plate",unique(obj@meta$plate))
  return(obj)
}

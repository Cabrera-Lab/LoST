## -----------------------------------------------------------------------------------------------
setGeneric(name = "group",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "group",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            group.LoST(obj)
          })


group.LoST <- function(obj){
  obj@meta$group_index <- obj@meta %>%
    dplyr::group_by(plate,`sample number`,replicate) %>%
    dplyr::group_indices()
  return(obj)
}

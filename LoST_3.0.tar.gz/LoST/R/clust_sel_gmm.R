clust_sel_gmm = function(x,jrange=1:5,dd=2,w=1) {
  ## x is an array,             ##  jrange n of clusters to be checked
  ##  dd number of differences
  # browser()
  score0=x[jrange]
  if (is.na(score0[1]) | is.na(score0[2])){
    res0 = c(1,2)
    return(res0)
  }
  if (score0[1]<score0[2]){
    res0 = c(1,2)
    return(res0)
  }

  d1 = if(dd==1) score0[-1] else -diff(score0)

  ## if the first difference percentage (compared to the original score) is small, <1%, regard it as only 1 cluster
  first_diff_percent = d1/score0[-length(score0)]*100
  if (first_diff_percent[1]<1){
    return(c(1,1))
  }

  # slope0 = diff(score0)#/score0[-length(score0)]*100
  # names(slope0) = as.numeric(names(slope0))-1
  ## slope0 is the slope of BIC after "x-th" cluster, e.g., names(slope0)==3 means the slope after 3 clusters (from 3 to 4 clusters), this is intended to deal with the situation that second diff is the largest but the slope is still steep.

  # plot(jrange[c(-1,-length(jrange))], -diff(d1)*100)
  if (dd==1){
    first_diff = d1#/d1[-length(d1)]*100
  } else if (dd==2){
    second_diff = -diff(d1)#/d1[-length(d1)]*100 # - cons0*num_clus0  ## cons0 = 5  to start with      #### add penalty
  }

  if (length(second_diff[!is.na(second_diff)])==1){
    res0 <- jrange[c(-1,-length(jrange))][which(!is.na(second_diff))]
    return(res0)
  } else {
    res0 <- jrange[c(-1,-length(jrange))][sort.list(second_diff,decreasing = T)[1:4]]
  }

  ## if the slope is still too steep, discard the first element and output the second element as the optimal cluster number
  # if (slope0[match(res0,names(slope0))][1]<0 && slope0[match(res0,names(slope0))][1]/slope0[match(res0,names(slope0))][2]>8){  # if the slope of the second element is 8 times smaller than the first, discard the first
  #   res0 = res0[-1]
  # }

  df <- rbind(jrange[c(-1,-length(jrange))],second_diff)
  df <- rbind(df, df[2,]/df[2,match(res0[1],df[1,])])

  if (length(which(df[3,]>1))!=0){
    df <- as.matrix(df[,-which(df[3,]>1)]) ## remove the column when it is ruled out by the steep slope issue
  }

  if (length(sort(df[1,which(df[3,]>0.9)],decreasing = T))<2){
    return(res0)
  } else{
    return(sort(df[1,which(df[3,]>0.9)],decreasing = T))
  } ## choose the higher number of cluster if the percentage difference is less than 10% (i.e., within 90%)
}


## -----------------------------------------------------------------------------------------------
setGeneric(name = "prep_final_res",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "prep_final_res",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            prep_final_res.LoST(obj)
          })


prep_final_res.LoST <- function(obj){
  ## merge the counts with meta file
  obj@final_res <- obj@meta
  for (j in 1:length(obj@meta$image_name)){
    obj@final_res$count[j] <- obj@count[[match(obj@final_res$image_name[j],names(obj@img))]]
    obj@final_res$px_ratio[j] <- obj@px_ratio[[match(obj@final_res$image_name[j],names(obj@img))]]
  }
  obj@final_res$censored = 0
  obj@final_res$censored[is.na(obj@final_res$count)]=1

  return(obj)
}

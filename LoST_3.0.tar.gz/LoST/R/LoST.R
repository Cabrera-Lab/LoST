setGeneric(name = "LoST",
           def = function(img_dir,
                          meta.file = system.file("extdata", "metafile_example.csv",package="LoST"),
                          database1 = system.file("extdata", "coverage_database1_size20.rds",package="LoST"),
                          blur.sigma = 1,
                          diameter = 500,
                          h_offset0=0,
                          v_offset0=0,
                          tol1 = 1 ,
                          denoise_size,
                          radius_cv = 0.11,
                          radius_roundness0 = 0.92,
                          radius_var1=1.7,
                          px_clus_ratio=0.35,
                          tol2Vec = c(0.15,0.125,0.1,0.05,0.04,0.03),
                          GMMitmax=300000,
                          GMmodel= c("EII","VII"),
                          GMM_initial_pt=10,
                          k0 = 5, ## number of times to fit GMM and take the mode of the counts in the 5 trials
                          skewness0 = 0.5,## criteria on skewness of the cluster radius for stratification, if very skewed, take only pixel of high intensity
                          size_factor = 2, ## criteria to correct by size
                          seed_num = 1992,
                          numCores,
                          use_dilute = T,
                          subset_row,
                          diff0=0.15,
                          nboot=500,
                          CI=T,
                          censor_thres = 120,
                          uncount_px_ratio=0.38,
                          dilute.model = T)
           standardGeneric("LoST"))


setMethod(f = "LoST",
          signature = signature(img_dir = "character"),
          definition = function(img_dir,
                                meta.file = system.file("extdata", "metafile_example.csv",package="LoST"),
                                database1 = system.file("extdata", "coverage_database1_size20.rds",package="LoST"),
                                blur.sigma = 1,
                                diameter = 500,
                                h_offset0=0,
                                v_offset0=0,
                                tol1 = 1 ,
                                denoise_size,
                                radius_cv = 0.11,
                                radius_roundness0 = 0.92,
                                radius_var1=1.7,
                                px_clus_ratio=0.35,
                                tol2Vec = c(0.15,0.125,0.1,0.05,0.04,0.03),
                                GMMitmax=300000,
                                GMmodel= c("EII","VII"),
                                GMM_initial_pt=10,
                                k0 = 5, ## number of times to fit GMM and take the mode of the counts in the 5 trials
                                skewness0 = 0.5,## criteria on skewness of the cluster radius for stratification, if very skewed, take only pixel of high intensity
                                size_factor = 2, ## criteria to correct by size
                                seed_num = 1992,
                                numCores,
                                use_dilute = T,
                                subset_row,
                                diff0=0.15,
                                nboot=500,
                                CI=T,
                                censor_thres = 120,
                                uncount_px_ratio=0.38,
                                dilute.model = T){

  ## -----------------------------------------------------------------------------------------------
  obj1 <- new(Class = "LoST")

  if(Sys.info()[['sysname']] == "Windows"){
    numCores = 1
  }else if(missing(numCores)){
    numCores = parallel::detectCores()/2
  }

  ## -----------------------------------------------------------------------------------------------
  obj1 <- get_img(obj = obj1,
                  dr = img_dir)


  ## -----------------------------------------------------------------------------------------------
  obj1 <- get_meta(obj = obj1,
                   file = meta.file)

  if (missing(subset_row)){
    if (length(which(is.na(match(names(obj1@img), obj1@meta$image_name))))!=0){
      obj1@img = obj1@img[-which(is.na(match(names(obj1@img), obj1@meta$image_name)))] ## remove images that are not listed in the meta file

      ## to modify other slots after choosing subset of images
      obj1@raw_img <- obj1@img
      obj1@completed <- vector(mode = "list",length = length(obj1@img))
    }
  } else {
    obj1@meta = obj1@meta[subset_row,]  ## modify the meta file when only a subset of images should be analyzed
    obj1@img = obj1@img[-which(is.na(match(names(obj1@img), obj1@meta$image_name)))] ## remove images that are not listed in the meta file
    ## to modify other slots after choosing subset of images
    obj1@raw_img <- obj1@img
    obj1@completed <- vector(mode = "list",length = length(obj1@img))
  }


  ## -----------------------------------------------------------------------------------------------
  check(obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- get_data_base(obj = obj1,
                        file = database1)
  # to add the coverage bound for 1 spot
  temp0 = obj1@coverage_data_base1
  temp0 = rbind(NA,temp0)
  temp0[1,] = cbind(500,20,1,0.0025,0.0025)
  obj1@coverage_data_base1 = temp0

  ## -----------------------------------------------------------------------------------------------
  obj1 <- group(obj = obj1)

  for (ii in 1:length(obj1@img)){
    obj1@center_offset[[ii]] = data.frame(cbind(h_offset0,v_offset0))
    obj1@well_diameter[[ii]] = diameter
  }

  ## -----------------------------------------------------------------------------------------------
  obj1 <- trim_img(obj = obj1, diameter = diameter, h_offset0 = h_offset0,v_offset0 = v_offset0)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- contrast_blur_img(obj = obj1,size = round((diameter+10)/10), sigma = blur.sigma)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- otsu_img(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- watershed_nor_img(obj = obj1, tolerance = tol1)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- watershed_clus_img(obj = obj1)


  ## -----------------------------------------------------------------------------------------------
  if (missing(denoise_size)){
    obj1 <- denoise_img(obj = obj1, diff0=diff0)
  } else {
    obj1 <- denoise_img(obj = obj1,
                        denoise_size = denoise_size, diff0=diff0)
  }

  ## -----------------------------------------------------------------------------------------------
  obj1 <- extreme_case_img(obj = obj1, uncount_px_ratio = uncount_px_ratio)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- clus_break_img(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- center_extr_img(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1@edge_iso_clus3 = mclapply(1:length(obj1@img_process),f2_edge_iso_clus3_img.LoST,obj = obj1,mc.cores = numCores)

  ## -----------------------------------------------------------------------------------------------
  obj1@edge_iso_clus3 <- mclapply(1:length(obj1@img_process),f2_edge3_adjacent_img.LoST,obj = obj1,mc.cores = numCores)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- radius3_img(obj = obj1)
  obj1 <- size_extr_img(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  for (tol00 in tol2Vec){
    obj1 <- refine_watershed_img(obj = obj1,tol0 = tol00,radius_cv = radius_cv,radius_var1=radius_var1,radius_roundness0 = radius_roundness0, px_clus_ratio=px_clus_ratio)
    obj1 <- watershed_clus_img(obj = obj1)
    if (missing(denoise_size)){
      obj1 <- denoise_img(obj = obj1,diff0 = diff0)
    } else {
      obj1 <- denoise_img(obj = obj1,
                          denoise_size = denoise_size,diff0=diff0)
    }
    obj1 <- clus_break_img(obj = obj1)

    obj1 <- center_extr_img(obj = obj1)

        obj1@edge_iso_clus3 <- mclapply(1:length(obj1@img_process),f2_edge_iso_clus3_img.LoST,obj = obj1,mc.cores = numCores)
    obj1@edge_iso_clus3 <- mclapply(1:length(obj1@img_process),f2_edge3_adjacent_img.LoST,obj = obj1,mc.cores = numCores)

    obj1 <- radius3_img(obj = obj1)
    obj1 <- size_extr_img(obj = obj1)
  }   ### don't remove the center even when there is no edge after common edge removal, since watershed identify spot through intensity difference, they are likely true spots

  ## -----------------------------------------------------------------------------------------------
  obj1 <- edge_iso_clus3_save_img(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- skewness_radius3(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- size_extr_img(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- is_circular(obj = obj1,radius_cv = radius_cv,radius_roundness0 = radius_roundness0, radius_var1=radius_var1, px_clus_ratio=px_clus_ratio)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- stratify_img(obj = obj1 , skewness0 = skewness0)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- count_GMM_img(obj = obj1,
                        itmax = GMMitmax,
                        sub_portion = GMM_initial_pt,
                        GMmodel = GMmodel,
                        seed_num = seed_num,
                        k0=k0)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- iso_clus3_img(obj = obj1,
                                 itmax = GMMitmax,
                                 sub_portion = GMM_initial_pt,
                                 GMmodel = GMmodel,
                                 seed_num = seed_num)

  ## -----------------------------------------------------------------------------------------------
  obj1@edge_iso_clus3 <- mclapply(1:length(obj1@img_process),f2_edge_iso_clus3_img.LoST,obj = obj1,mc.cores = numCores)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- radius3_img(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- radiusRatio_iso_clus3_img(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- size_extr_img(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- is_circular(obj = obj1,radius_cv = radius_cv,radius_roundness0 = radius_roundness0, radius_var1=radius_var1, px_clus_ratio=px_clus_ratio)

  ## -----------------------------------------------------------------------------------------------
  obj1@edge_iso_clus3_backup <- mclapply(1:length(obj1@img_process),f2_edge_iso_clus3_img.LoST,obj = obj1,mc.cores = numCores)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- skewness_radius3(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1@clus_multilayer <- mclapply(1:length(obj1@img_process), f2_stratify_img.LoST,obj=obj1, skewness0 = skewness0,mc.cores = numCores)

  if (use_dilute == T){
    ## -----------------------------------------------------------------------------------------------
    obj1 <- extr_avg_spot_size(obj = obj1)
    ## -----------------------------------------------------------------------------------------------
    obj1<- correct_by_size_img(obj = obj1,size_factor=size_factor)

    ## -----------------------------------------------------------------------------------------------
    abc <- mclapply(1:length(obj1@img_process),f2_iso_clus3_img.LoST,obj = obj1,itmax=GMMitmax,sub_portion=GMM_initial_pt,GMmodel=GMmodel,seed_num=seed_num,mc.cores = numCores)

    ## -----------------------------------------------------------------------------------------------
    obj1@iso_clus <- mclapply(1:length(obj1@img_process),f1_assign_iso_clus.LoST, abc = abc,mc.cores = numCores)
    obj1@clus_center <- mclapply(1:length(obj1@img_process),f1_assign_clus_center.LoST, abc = abc,mc.cores = numCores)
    obj1@is_GMM <- mclapply(1:length(obj1@img_process),f1_assign_is_GMM.LoST, abc = abc,mc.cores = numCores)

    ## -----------------------------------------------------------------------------------------------
    ## getting new iso_clus3 and new clus_center3 after correction
    obj1@edge_iso_clus3 <- mclapply(1:length(obj1@img_process),f2_edge_iso_clus3_img.LoST,obj = obj1,mc.cores = numCores)

  }

  ## -----------------------------------------------------------------------------------------------
  obj1 <- radius3_img(obj = obj1)
  obj1 <- radiusRatio_iso_clus3_img(obj = obj1)
  obj1 <- abs_cor_iso_clus3_img(obj = obj1)
  obj1 <- eigenval_percent_extr_img(obj = obj1)
  obj1 <- size_extr_img(obj = obj1)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- display_circle_iso_clus3_img(obj = obj1) ## to output the re-constructed circle (new)
  obj1@edge_iso_clus3 <- mclapply(1:length(obj1@img_process),f2_edge_iso_clus3_img.LoST,obj = obj1,mc.cores = numCores)

  ## -----------------------------------------------------------------------------------------------
  obj1 <- prep_res.LoST(obj = obj1)
  obj1 <- prep_final_res.LoST(obj = obj1)
  obj1@final_res$new_count = obj1@final_res$count

  if (use_dilute == T){
    ## simulate coverage for detecting censoring
    res0_sim = NULL
    for (kk in 1:length(obj1@img_process)){
      if (is.na(obj1@count[[kk]])){
        res0_sim = rbind(res0_sim,matrix(NA,nrow = 1,ncol = 6))
        res0_sim[kk,1] = names(obj1@img)[[kk]]
        next
      } else if (is.na(obj1@avg_spot_size[[kk]]) | obj1@count[[kk]]==0){
        res0_sim = rbind(res0_sim,matrix(NA,nrow = 1,ncol = 6))
        res0_sim[kk,1] = names(obj1@img)[[kk]]
        next
      }
      res0_sim = rbind(res0_sim,matrix(cbind(names(obj1@img)[[kk]],sim_coverage.LoST(d1 = 500,d2o = obj1@avg_spot_size[[kk]],d1_real = 336,sim_size0 = obj1@count[[kk]],seed_num = seed_num,num_cores0 = numCores)),nrow = 1,ncol = 6))
    }
    res0_sim = data.frame(res0_sim)
    names(res0_sim) = c("names(obj1@img)[[kk]]", "d1","d2", "number of spots", "coverage 2.5%" ,"coverage 97.5%"  )
    res0_sim[,-1] = apply(res0_sim[,-1],MARGIN = 2,FUN = as.numeric)

    res0_sim = res0_sim[match(obj1@final_res$image_name,res0_sim$`names(obj1@img)[[kk]]`),]

    obj1 <- censoring(obj = obj1,res0_sim = res0_sim)

  }


  obj1 <- prep_series(obj = obj1)

  if (use_dilute == T){
    ## -----------------------------------------------------------------------------------------------
    ### prepare the "final_res" for dilution series modeling
    obj1@final_res$disagreement = FALSE

    obj1@final_res$`censor threshold` = censor_thres
    obj1@final_res$disagreement[is.na(obj1@final_res$count)]=TRUE
    res0_temp = NULL
    for (i in unique(obj1@final_res$`sample number`)){
      temp0 = obj1@final_res[obj1@final_res$`sample number`==i,]
      for (j in unique(temp0$replicate)){
        temp00 = temp0[temp0$replicate==j,]
        ## if there are diluted samples that are censored, all upstream samples should be censored
        num0 = temp00$`dilution number`[which(temp00$censored==1)][1]
        temp00$censored[temp00$`dilution number`<num0] = 1
        temp00$disagreement[temp00$censored==1] = TRUE

        ## find out the max count in a series and if there is smaller count in less diluted sample, treat it as censored
        if (which.max(temp00$count)-1 != 0){
          temp00$censored[1:(which.max(temp00$count)-1)] = 1
        }
        temp00$disagreement[temp00$censored==1] = TRUE

        res0_temp = rbind(res0_temp,temp00)
      }
    }
    obj1@final_res = res0_temp
  }

  ## -----------------------------------------------------------------------------------------------
  ### perform dilution series modeling and estimate then neat sample conc
  if (dilute.model==T){
    obj1 <- lambda.est_JLE(obj1,nboot = nboot, CI = CI,seed_num=seed_num)
  }

  ## -----------------------------------------------------------------------------------------------
  ## provide image number in "final_res"
  obj1@final_res$img_num = match(obj1@final_res$image_name,names(obj1@img))


 return(obj1)
          }


)


#lambda.est_JLE: method to get the estimated lambdas, i.e., the numbers of particles in the neat samples, and corresponding bootstrap CIs,  for an LoST object.
#obj: an LoST object
#nboot: the number of bootstrap samples generated for CI
#level: confidence level for bootstrap CI
#CI: If TRUE, output estimates with confidence intervals. If FLASE, only output the point estimates.

## -----------------------------------------------------------------------------------------------
setGeneric(name = "lambda.est_JLE",
           def = function(obj,nboot = 500,level = 0.95, CI = TRUE,seed_num=1234)
             standardGeneric("lambda.est_JLE")
)

setMethod(f = "lambda.est_JLE",
          signature = signature(obj = "LoST"),
          definition = function(obj,nboot = 500,level = 0.95, CI = TRUE,seed_num=1234) {
            info = obj@final_res
            plate.num = unique(info$plate)
            num_plate = length(plate.num)
            set.seed(seed_num)

            result = NULL
            for (i in 1:num_plate) {
              sample.num = unique(info[info$plate == i,]$`sample number`)
              num_samp = length(sample.num)
              for (j in 1:num_samp) {
                info_samp = info[which(info$plate == i & info$`sample number`==j),]
                m = length(unique(info_samp$replicate))
                result_rep = NULL
                for (k in 1:m) {
                  info_rep = info[which(info$plate == i & info$`sample number`==j & info$replicate ==k & info$disagreement == FALSE),]
                  # conditions could be changed according to the result table, such as disagreement.
                  data = info_rep$count
                  if (all(data==0)){
                    if (isTRUE(CI)){
                      temp0 = as.matrix(t(c(0,0,0)))
                      colnames(temp0) = c("lambda.est","bootstrap.CI_L", "bootstrap.CI_R")
                      result_rep = rbind(result_rep, temp0)
                    } else{
                      temp0 = as.matrix(0)
                      colnames(temp0) = "lambda.est"
                      result_rep = rbind(result_rep, temp0)
                    }
                    next
                  }
                  d = info_rep$`dilution number`
                  p = 1/info_rep$dilution_factor[1]
                  s = info_rep$`sampling proportion (s)`[1]
                  cen = info_rep$`censor threshold`[1] # a column indicating the censoring threshold, i.e., 120
                  est = lambda.est(data,d,p,s,cen,nboot,CI,level)
                  result_rep = rbind(result_rep, as.matrix(est))
                }
                result = rbind(result,c(i,j,as.matrix(colMeans(result_rep))))
              }
            }

            if(CI == TRUE){
              colnames(result) = c("plate","sample number","Lambda.est","Bootstrap.CI_L","Bootstrap.CI_R")
            }else{
              colnames(result) = c("plate","sample number","Lambda.est")
            }

            result = as.data.frame(result)

            #return(result)

            print(result)
            obj@est_res = result

            return(obj)
          })




#lambda.est: function to get the estimated lambda, i.e., the number of particles in the neat sample, and corresponding bootstrap CI,  for a neat sample by JLE with Poisson model.
#data: a vector of a dilution serial count data for a neat sample.
#d: a vector of dilution levels corresponding to each count data.
#p: dilution proportion, i.e, 1/dilution factor
#s: sampling proportion from tubes to wells.
#cen: a positive integer indicating a threshold about censoring. Any counts larger than this integer would be regarded as right-censored.
#nboot: the number of bootstrap samples generated for CI
#level: confidence level for bootstrap CI
#CI: If TRUE, output estimate with confidence interval. If FLASE, only output the point estimate.

lambda.est <- function(data,d,p,s,cen,nboot = 500,CI = TRUE,level = 0.95){

  if(p <=0 | p >=1){
    stop("dilution proportion p should be between 0 and 1")
  }
  if(s <= 0 | s >= 1){
    stop("sampling proportion s should be between 0 and 1")
  }

  if(cen %% 1 != 0 | cen <= 0){
    stop("cen should be a positive integer")
  }
  if(length(d) != length(data)){
    stop("The length of dilution numbers is not the same as the number of counts.
         The dilution number for each count should be provided.")
  }



  lambda.poi = optimLambda(data,d,p,s,cen)
  if(CI ==TRUE){
    lambda.ci.boot = ci.boot(data,d,p,s,cen,nboot,level)
    result = data.frame(lambda.est = lambda.poi, bootstrap.CI_L = lambda.ci.boot[1],bootstrap.CI_R = lambda.ci.boot[2])
  }else{
    result = data.frame(lambda.est = lambda.poi)
  }

  return(result)

}




#optimLambda: function to get the optimal estimated lambda, i.e., the number of particles in the neat sample, for a sample by JLE with Poisson model.
#data: a vector of a dilution serial count data for a neat sample.
#d: a vector of dilution levels corresponding to each count data.
#p: dilution proportion, i.e, 1/dilution factor
#s: sampling proportion from tubes to wells.
#cen: a positive integer indicating a threshold about censoring. Any counts larger than this integer would be regarded as right-censored.

optimLambda <- function(data,d,p,s,cen){

  if(p <=0 | p >=1){
    stop("dilution proportion p should be between 0 and 1")
  }
  if(s <= 0 | s >= 1){
    stop("sampling proportion s should be between 0 and 1")
  }

  if(cen %% 1 != 0 | cen <= 0){
    stop("cen should be a positive integer")
  }
  if(length(d) != length(data)){
    stop("The length of dilution numbers is not the same as the number of counts.
         The dilution number for each count should be provided.")
  }


  opti.poi <- function(dat,d,p,s,cen){
    q = p^d*s
    x = as.vector(dat)
    n =  as.numeric(x > cen)
    if(sum(n == 1) >0){
      cen_v = cen/p^(max(d[n==1])-d[n==1])
      x[n==1] = cen_v
    }

    loglike <- function(lambda){
      lambda_new = lambda*q
      sum_censor = sum(apply(cbind(x[n==1],lambda_new[n==1]), 1,
                             function(t) log(ppois(t[1],lambda = t[2],lower.tail = FALSE))))
      sum_uncen = sum(apply(cbind(x[n==0],lambda_new[n==0]), 1,
                            function(t) log(dpois(t[1],lambda = t[2]))))

      return(sum_censor+sum_uncen)
    }
    max_un = max(x[n==0])
    max2_un = sort(x[n==0])[length(x[n==0]) - 1]

    if (length(max2_un)==0){
      start = max_un/q[which(x == max_un)[1]]
    } else{
      start = mean(max_un/q[which(x == max_un)[1]], max2_un/q[which(x == max2_un)[1]])
    }

    est = optimize(loglike, c(start*0.5,start*2+0.0000001),maximum = TRUE)
    return(round(est$maximum))
  }


  return(round(opti.poi(data,d,p,s,cen)))
}





#ci.boot: function to get the bootstrap CI for the estimated lambda, i.e., the number of particles in the neat sample, for a sample by JLE with Poisson model.
#data: a vector of a dilution serial count data for a neat sample.
#d: a vector of dilution levels corresponding to each count data.
#p: dilution proportion, i.e, 1/dilution factor
#s: sampling proportion from tubes to wells.
#cen: a positive integer indicating a threshold about censoring. Any counts larger than this integer would be regarded as right-censored.
#nboot: the number of bootstrap samples generated for CI
#level: confidence level for bootstrap CI

ci.boot <- function(data,d,p,s,cen,nboot = 500, level = 0.95){

  if(p <=0 | p >=1){
    stop("dilution proportion p should be between 0 and 1")
  }
  if(s <= 0 | s >= 1){
    stop("sampling proportion s should be between 0 and 1")
  }

  if(cen %% 1 != 0 | cen <= 0){
    stop("cen should be a positive integer")
  }
  if(length(d) != length(data)){
    stop("The length of dilution numbers is not the same as the number of counts.
         The dilution number for each count should be provided.")
  }


  boot_poi = NULL
  est.poi = optimLambda(data,d,p,s,cen)
  for (i in 1:nboot) {
    xrep_poi = gen_rep(est.poi,p,s,max(d),1)
    if (all(xrep_poi==0)){
      boot_poi = c(boot_poi,0)
      next
    }
    boot_poi = c(boot_poi,optimLambda(xrep_poi[d],d,p,s,cen))
  }
  level_l = (1-level)/2
  ci = as.vector(quantile(boot_poi,c(level_l,1-level_l)))

  return(data.frame(bootstrap.CI_L = ci[1],bootstrap.CI_R = ci[2]))
}

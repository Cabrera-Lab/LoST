is_one_tree_clus.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@is_one_tree[[i]] <- list()
    for (j in 1:length(obj@iso_clus2[[i]])){
      tree_dat0 = data.frame(cbind(obj@clus_eigenRatio[[i]][[j]], obj@clus_cor_edge[[i]][[j]], obj@clus_radiuRatio[[i]][[j]], obj@clus_size[[i]][[j]]))
      names(tree_dat0) = c("eigenRatio","cor_edge","radiusRatio","size")
      obj@is_one_tree[[i]][[j]] <- as.numeric(as.character(predict(obj@tree,newdata = tree_dat0,type = "class")))   ## identified as one or more-than-one cluster by classification tree
    }
  }
  return(obj)
}


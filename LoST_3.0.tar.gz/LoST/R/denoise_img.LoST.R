## -----------------------------------------------------------------------------------------------
setGeneric(name = "denoise_img",
           def = function(obj, denoise_size, diff0, ...) return(NULL)
)

setMethod(f = "denoise_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, denoise_size, diff0) {
            denoise_img.LoST(obj, denoise_size = denoise_size, diff0 = diff0)
          })

denoise_img.LoST <- function(obj, denoise_size,diff0=0.1){
  for (i in 1:length(obj@img_process)){
    if (missing(denoise_size)){
      denoise_size = prod(dim(obj@img[[i]]))*0.000076
    }

    obj@res[[i]] <- obj@res[[i]][which(obj@res[[i]]$number_of_pixels > denoise_size),] ## use the area of image times a percentage in order to get the threshold of noise
    obj@res[[i]] <- obj@res[[i]][obj@res[[i]]$watershed_group!=0,]
    obj@res[[i]] <- obj@res[[i]][obj@res[[i]]$max_diff_from_threshold > diff0,]

    if (length(obj@res[[i]])==0){
      obj@px_ratio[[i]] <- 0
    } else{
      obj@px_ratio[[i]] <- sum(obj@res[[i]]$number_of_pixels)/obj@base_px[[i]]
    }
  }
  return(obj)
}

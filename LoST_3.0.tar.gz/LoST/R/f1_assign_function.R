f1_assign_iso_clus.LoST <- function(j, abc = abc){
  return(abc[[j]]$iso_clus)
}
f1_assign_clus_center.LoST <- function(j, abc = abc){
  return(abc[[j]]$clus_center)
}
f1_assign_is_GMM.LoST <- function(j, abc = abc){
  return(abc[[j]]$is_GMM)
}

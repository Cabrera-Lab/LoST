## -----------------------------------------------------------------------------------------------
setGeneric(name = "edge_iso_clus3_save_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "edge_iso_clus3_save_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            edge_iso_clus3_save_img.LoST(obj)
          })


edge_iso_clus3_save_img.LoST <- function(obj){

  for (i in 1:length(obj@img_process)){
    obj@edge_iso_clus3_backup[[i]] <- list()
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    for (j in 1:length(obj@iso_clus[[i]])){
       obj@edge_iso_clus3_backup[[i]][[j]] <- data.frame(concaveman::concaveman(obj@iso_clus[[i]][[j]]$save_pos0,concavity = 1))
      names(obj@edge_iso_clus3_backup[[i]][[j]]) = c("row", "col")
    }
  }
  return(obj)
}

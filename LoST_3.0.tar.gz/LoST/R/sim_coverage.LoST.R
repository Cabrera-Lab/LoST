################ simulation ###############
sim_coverage.LoST <- function(d1 = 500, d2o = 42, d1_real = 336, seed_num = 1992, sim_size0=100,num_cores0 = 1){


  res_sim0 = NULL
  df0_circle_size = d1
  # d1_real = 336   ## the real spot does not appear near edge, so define a real diameter

  mcsapply<-function (X, FUN, ..., simplify = TRUE, USE.NAMES = TRUE, mc.preschedule = TRUE,
                      mc.set.seed = TRUE, mc.silent = FALSE, mc.cores = getOption("mc.cores", 2L),
                      mc.cleanup = TRUE, mc.allow.recursive = TRUE, affinity.list = NULL )
  {
    answer <- mclapply(X = X, FUN = FUN, ...,mc.preschedule = mc.preschedule,
                       mc.set.seed = mc.set.seed, mc.silent = mc.silent, mc.cores = mc.cores,
                       mc.cleanup = mc.cleanup, mc.allow.recursive = mc.allow.recursive, affinity.list = affinity.list)
    if (USE.NAMES && is.character(X) && is.null(names(answer)))
      names(answer) <- X
    if (!isFALSE(simplify) && length(answer))
      simplify2array(answer, higher = (simplify == "array"))
    else answer
  }


  set.seed(seed_num)
  sim0=NULL
  sim_fun <- function(k){
    mm1 <- matrix(rep((1:d1 - d1/2)^2, d1),
                  ncol = d1,
                  byrow = TRUE)
    mm_sim <- sqrt(mm1 + t(mm1))
    sett0 <- which(mm_sim < d1/2-5, arr.ind = TRUE)  #d1/2-5
    sett1 <- which(mm_sim > d1/2-5, arr.ind = TRUE)  #d1/2-5
    mm_sim[sett0]=1
    mm_sim[sett1]=NA

    d2 = round(d2o * rchisq(1,df = df0_circle_size)/df0_circle_size) ## impose uncertainty to the diameter of spot simulated
    d1_real_temp = d1_real - 2*(d2/2)   ## so that the phage will not go beyond the edge

    m1 <- matrix(rep((1:d1_real_temp - d1_real_temp/2)^2, d1_real_temp),
                 ncol = d1_real_temp,
                 byrow = TRUE)
    mm <- sqrt(m1 + t(m1))
    set0 <- which(mm < d1_real_temp/2-5, arr.ind = TRUE)  #d1_real_temp/2-5
    set0 = set0 + (d1 - d1_real_temp)/2  ## to align the center with the background circle


    sim_center0 = set0[sample(1:dim(set0)[1],size = sim_size0,replace = F),]
    if (is.null(dim(sim_center0))){
      sim_center0 = data.frame(rbind(sim_center0))
    } else{
      sim_center0 = data.frame(sim_center0)
    }

    #### make small circles
    m11 <- matrix(rep(((1:d2 - d2/2))^2, d2),
                  ncol = d2,
                  byrow = TRUE)
    mmm <- sqrt(m11 + t(m11))
    set00 <- which(mmm < d2/2, arr.ind = TRUE)
    set00 = set00 - (d2/2)  ## align the small circle to be centered at origin, i.e., (0,0)

    for (j in 1:length(sim_center0$row)){
      # points(set00[,1]+sim_center0$row[j],set00[,2]+sim_center0$col[j],asp=1,pch=16,xlim=c(0,500),ylim=c(0,500))
      set1 = cbind(set00[,1]+sim_center0$row[j],set00[,2]+sim_center0$col[j])
      set1 = set1[rowSums(set1<d1)==2,]
      set1 = set1[rowSums(set1>0)==2,]


      mm_sim[set1]=0


    }

    non_phage0 <- which(mm_sim>0.5,arr.ind = T)
    phage0 <- which(mm_sim<0.5,arr.ind = T)
    blank0 <- which(is.na(mm_sim),arr.ind = T)
    sim0 = cbind(dim(phage0)[1]/(dim(phage0)[1]+dim(non_phage0)[1]),j)

    print(k)
    return(sim0)
  }

  sim0 = t(mcsapply(1:500,FUN = sim_fun,mc.cores = num_cores0))

  res_sim0 = rbind(res_sim0, c(d1,d2o,sim_size0,c(quantile(sim0[,1],probs = c(0.025,0.975)))))
  print(paste("#################   number of phages: ",    sim_size0))

  res_sim0 = data.frame(res_sim0)
  names(res_sim0) = c("d1","d2","number of spots","coverage 2.5%","coverage 97.5%")

  return(res_sim0)
}


# saveRDS(res_sim0,file = "coverage_database1_size20.rds")


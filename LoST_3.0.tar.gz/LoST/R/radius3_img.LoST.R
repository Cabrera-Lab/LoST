## -----------------------------------------------------------------------------------------------
setGeneric(name = "radius3_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "radius3_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            radius3_img.LoST(obj)
          })

radius3_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@radius3[[i]] <- list()
    obj@radius3_var[[i]] <- list()
    obj@radius3_cv[[i]] <- list()
    obj@radius3_roundness[[i]] <- list()
    obj@clus_count3[[i]] <- list()
    for (j in 1:length(obj@edge_iso_clus3[[i]])){
      obj@radius3[[i]][[j]] = sqrt((obj@edge_iso_clus3[[i]][[j]][,1] - obj@clus_center[[i]][[j]][,1])^2 + (obj@edge_iso_clus3[[i]][[j]][,2] - obj@clus_center[[i]][[j]][,2])^2)
      temp0 = obj@radius3[[i]][[j]]
      temp0 = temp0[temp0<quantile(temp0,0.95) & temp0>quantile(temp0,0.05)]
      obj@radius3_cv[[i]][[j]] = sd(temp0)/mean(temp0)
      obj@radius3_var[[i]][[j]] = sd(temp0)
      obj@radius3[[i]][[j]] = round(obj@radius3[[i]][[j]])  ## added on Mar10, 2023

      ## mean roundness
      obj@radius3_roundness[[i]][[j]] = sum(mean(temp0)/(abs(temp0-mean(temp0))+mean(temp0)))/length(temp0)

      obj@clus_count3[[i]][[j]] = 1
    }


  }
  return(obj)
}


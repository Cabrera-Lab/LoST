## -----------------------------------------------------------------------------------------------
setGeneric(name = "correct_by_size_img",
           def = function(obj,size_factor, ...) return(NULL)
)

setMethod(f = "correct_by_size_img",
          signature = signature(obj = "LoST"),
          definition = function(obj,size_factor=4) {
            correct_by_size_img.LoST(obj,size_factor = size_factor)
          })

correct_by_size_img.LoST <- function(obj, size_factor = 4){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@clus_correct[[i]] = list()
    for (j in 1:length(obj@is_one_tree[[i]])){
      if (is.na(obj@sd_spot_size[[i]])){
        next
      }
      obj@clus_correct[[i]][[j]]=0
      if (obj@is_one_tree[[i]][[j]]!=1 | (obj@is_one_tree[[i]][[j]]==1 & obj@clus_size[[i]][[j]] > (size_factor*pi*(obj@avg_spot_size[[i]]/2)))){
        ### correct the count by size

        temp0_diameter = qnorm(p = 0.9, mean = obj@avg_spot_size[[i]],sd = obj@sd_spot_size[[i]])
        temp0 <- round(obj@clus_size[[i]][[j]]/(pi*(temp0_diameter/2)^2))
        if (obj@clus_count3[[i]][[j]][1] < temp0){
          obj@clus_count3[[i]][[j]][1] <- temp0
          obj@clus_correct[[i]][[j]] = 1
        }

      }
    }
  }
  return(obj)
}

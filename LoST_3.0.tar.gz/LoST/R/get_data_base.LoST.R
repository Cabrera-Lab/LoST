## -----------------------------------------------------------------------------------------------
setGeneric(name = "get_data_base",
           def = function(obj, file,...) return(NULL)
)

setMethod(f = "get_data_base",
          signature = signature(obj = "LoST"),
          definition = function(obj, file) {
            get_data_base.LoST(obj,file=file)
          })


get_data_base.LoST <- function(obj,
                          file){
  ## read the coverage database (i.e., a dataframe indicating the coverage ratio in pixel for a given spot size and number of spots)
  obj@coverage_data_base1 <- readRDS(file = file)
  return(obj)
}

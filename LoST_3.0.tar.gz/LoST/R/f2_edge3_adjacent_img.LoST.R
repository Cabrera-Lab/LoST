
f2_edge3_adjacent_img.LoST <- function(i, obj=obj){
  e0 <- new.env()

  if (length(obj@iso_clus[[i]])==0){
    # next
    return()
  }
  if (length(obj@edge_iso_clus3[[i]])==1){  ## only one cluster is identified originally
    # next
    return(obj@edge_iso_clus3[[i]])
  }

  choices<-choose(length(obj@edge_iso_clus3[[i]]),2)
  combs<-combn(length(obj@edge_iso_clus3[[i]]),2)

  invisible(lapply(1:choices, f1_edge3_adjacent_img.LoST,combs=combs,obj=obj,i=i,e0=e0))

  return(e0$temp0)
}


f1_edge3_adjacent_img.LoST <- function(k, combs=combs, obj = obj, i = i,e0 = e0){
  if (k == 1){
    temp0 = obj@edge_iso_clus3[[i]]
  } else{
    temp0 = e0$temp0
  }

  pair<-c(combs[1,k], combs[2,k])
  A = obj@edge_iso_clus3[[i]][[pair[1]]]
  B = obj@edge_iso_clus3[[i]][[pair[2]]]

  ## check if A and B are too far away, skip them to save time, check if range(A_row) is within range(B_row)+-1, vice versa, and for "col" as well.
  if ((any(data.table::between(range(B[,1]),lower = range(A[,1])[1]-1, upper = range(A[,1])[2]+1)) | any(data.table::between(range(A[,1]),lower = range(B[,1])[1]-1, upper = range(B[,1])[2]+1))) && (any(data.table::between(range(B[,2]),lower = range(A[,2])[1]-1, upper = range(A[,2])[2]+1)) | any(data.table::between(range(A[,2]),lower = range(B[,2])[1]-1, upper = range(B[,2])[2]+1)))){
    euklDist <- sqrt(apply(array(apply(B,1,function(x){(x-t(A))^2}),c(ncol(A),nrow(A),nrow(B))),2:3,sum)) ## calculate the euclidean distance in a pairwise manner

    set2 = which(euklDist<=sqrt(2),arr.ind = T)
    if (length(set2)!=0){
      temp0[[pair[1]]] <- A[-set2[,"row"],] ## edge without common edge, for cluster A
      temp0[[pair[2]]] <- B[-set2[,"col"],] ## edge without common edge, for cluster B
    }
  }
  assign("temp0",value = temp0,envir = e0)
  return(NULL)
}

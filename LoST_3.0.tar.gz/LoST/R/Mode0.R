Mode0 <- function(x,na.rm=T) {   ## mode function for a continuous distribution
  if (na.rm==T){
    x = x[!is.na(x)]
  }
  d <- density(x)
  d$x[which.max(d$y)]
}

# DS, 12/25/2021

get_img.LoST <- function(obj,
                         dr){
  obj@directory = dr
  files <- list.files(path = dr)
  files_full <- paste(dr,
                      files,
                      sep = "/")

  for (i in 1:length(files)) {
    image_i <- jpeg::readJPEG(files_full[i])

    if (!is.na(dim(image_i)[3])){
      image_i <- image_i[, , 1]
    }

    # if (img_color == TRUE){
    #   image_i <- image_i[, , 1]
    # }

    obj@img[[i]] <- EBImage::flip(EBImage::rotate(image_i,
                                                  angle = 270))
  }
  names(obj@img) <- files

  obj@raw_img <- obj@img

  ## define the "completed" indicator to indicate the completeness
  obj@completed <- vector(mode = "list",length = length(obj@img))

  return(obj)
}

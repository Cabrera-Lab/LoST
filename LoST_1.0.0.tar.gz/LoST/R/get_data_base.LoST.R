get_data_base.LoST <- function(obj,
                          file){
  ## read the coverage database (i.e., a dataframe indicating the coverage ratio in pixel for a given spot size and number of spots)
  obj@coverage_data_base1 <- readRDS(file = file)
  return(obj)
}

refine_clus_count3_img.LoST <- function(obj, itmax=3, sub_portion=3, GMmodel = "EII", seed_num=1992){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    record0 = NULL
    for (j in 1:length(obj@radius3_var[[i]])){
      if (is.na(obj@radius3_var[[i]][[j]])){
        obj@iso_clus3[[i]][[j]] = NA
        obj@clus_center3[[i]][[j]] = NA
        obj@clus_count3[[i]][[j]] = NA
        record0 = c(record0,j)
        next
      }
      if (obj@radius3_var[[i]][[j]] > 2){
        obj@clus_count3[[i]][[j]] = obj@clus_count3[[i]][[j]]+1

        y <- obj@iso_clus3[[i]][[j]]
        set3 <- which(y>0,arr.ind = T)

        ### GMM
        set.seed(seed_num)
        # gmm0 <- ClusterR::Optimal_Clusters_GMM(obj@clus_multilayer[[i]][[j]],max_clusters = 10,criterion = "BIC",km_iter = 3,em_iter = 3,dist_mode = "eucl_dist",plot_data = F)
        if (is.na(sub_portion)){
          mod_gmm0 <- mclust::Mclust(set3,G = obj@clus_count3[[i]][[j]],modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F)
        } else {
          mod_gmm0 <- mclust::Mclust(set3,G = obj@clus_count3[[i]][[j]],modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F,initialization = list(subset=sample(1:nrow(set3),size = nrow(set3)/sub_portion)))
        }

        temp_center0 = list()
        temp0 = list()
        for (k in unique(mod_gmm0$classification)){
          set1 <- set3[mod_gmm0$classification==k,]
          temp0[[k]] = obj@img_process[[i]]
          set0 = which(temp0[[k]]>0,arr.ind = T)
          temp0[[k]][set0]=0
          temp0[[k]][set1]=1


          temp_center0[[k]] = data.frame(t(mod_gmm0$parameters$mean[,k]))
        }
        obj@iso_clus3[[i]][[j]]=list()
        obj@iso_clus3[[i]] <- append(obj@iso_clus3[[i]],temp0) ## update iso_clus3 for newly identified cluster
        # print(paste0("iso3 ",i," ",j))

        obj@clus_center3[[i]][[j]]=list()
        obj@clus_center3[[i]] <- append(obj@clus_center3[[i]],temp_center0)
      }

    }
    for (jj in rev(record0)){   ## rev(), because to avoid altering the sub-list number after removing a sub-list
      obj@iso_clus3[[i]][[jj]] = NULL
      obj@clus_center3[[i]][[jj]] = NULL
      obj@clus_count3[[i]][[jj]] = NULL
    }
    obj@iso_clus3[[i]] = Filter(length, obj@iso_clus3[[i]])  ## filter the list with zero length
    obj@clus_center3[[i]] = Filter(length, obj@clus_center3[[i]])
  }
  return(obj)
}




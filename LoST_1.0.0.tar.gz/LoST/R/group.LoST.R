group.LoST <- function(obj){
  obj@meta$group_index <- obj@meta %>%
    dplyr::group_by(plate,`sample number`,replicate) %>%
    dplyr::group_indices()
  return(obj)
}

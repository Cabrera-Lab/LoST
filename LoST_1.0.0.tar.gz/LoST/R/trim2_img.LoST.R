trim2_img.LoST <- function(obj, diameter = 500, h_offset0=0, v_offset0=0){
  for (i in 1:length(obj@img)){
    nrow0 = dim(obj@img[[i]])[1]
    ncol0 = dim(obj@img[[i]])[2]
    # if (nrow0 %% 2 ==0){
    #
    # }
    m0 <- matrix(rep((1:ncol0 - (ncol0/2 + v_offset0))^2, nrow0),  ## m0 is a matrix (dimension: nrow0 * ncol0) where each value represents the vertical distance
                 ncol = ncol0,
                 byrow = TRUE)

    m0b <- matrix(rep((1:nrow0 - (nrow0/2 + h_offset0))^2, ncol0),  ## m0b is a matrix (dimension: ncol0 * nrow0) where each value represents the horizontal distance, which will be transposed afterward
                  ncol = nrow0,
                  byrow = TRUE)
    m1 <- sqrt(m0+t(m0b))  ## matrix of radius

    obj@trim[[i]] <- which(m1 >= (diameter/2), arr.ind = TRUE)
    obj@base_px[[i]] <- dim(which(m1 < (diameter/2), arr.ind = TRUE))[1]
    obj@img_process[[i]] <- obj@img[[i]]
    obj@img_process[[i]][obj@trim[[i]]] <- NA   ## record the image after trim
  }
  names(obj@img_process) = names(obj@img)
  return(obj)
}

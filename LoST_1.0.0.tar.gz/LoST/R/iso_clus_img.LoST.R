iso_clus_img.LoST <- function(obj, obj2, ii){  ## obj can be the image after watershed, obj2 is the original image retaining the intensity
  set2 <- which(obj==ii,arr.ind = T)
  save_pos0 = set2
  save_intensity0 = obj2[set2]

  # y0 <- obj2
  # y0[set2] <- 255
  # set1 <- which(y0 < 200, arr.ind = TRUE)
  # obj2[set1] <- 0    ## obj2 is a matrix with isolation on a particular cluster

  return(list(save_pos0=save_pos0,save_intensity0=save_intensity0))
}

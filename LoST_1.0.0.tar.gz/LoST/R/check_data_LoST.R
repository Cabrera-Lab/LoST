#check obj@meta:
check_data.LoST <- function(obj){
  check_data(obj@meta)
}

otsu_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    threshold0 = EBImage::otsu(obj@img_process[[i]])
    if (abs(Mode0(obj@img_process[[i]],na.rm = T)-threshold0)<0.02){  ## to deal with the situation that the pixel of phages is not many due to small number
      threshold0 = quantile(obj@img_process[[i]],probs = 0.99,na.rm = T)
      threshold1 = quantile(obj@img_process[[i]],probs = 0.995,na.rm = T)
      threshold2 = quantile(obj@img_process[[i]],probs = 0.999,na.rm = T)
      threshold0 = min(threshold0,threshold1,threshold2)
      # print("Otsu method does not work. (Probably the number of phage is too small.)")
    }
    obj@otsu_thres[[i]] = threshold0
    set2 <- which(obj@img_process[[i]] < threshold0, arr.ind = TRUE)
    obj@img_process[[i]][set2] <- 0

    ## to record the coverage in pixel
    # y1 <- obj@img_process[[i]]
    # set11 <- which(y1 >= threshold0, arr.ind = TRUE)
    # y1[set11] <- 1
    # y1[set2] <- 0
    # obj@px_ratio[[i]] <- dim(which(y1>0.5,arr.ind = T))[1]/obj@base_px[[i]]
  }
  return(obj)
}

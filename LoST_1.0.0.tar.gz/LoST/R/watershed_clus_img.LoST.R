watershed_clus_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    res0 = NULL
    for (j in sort(unique(as.numeric(obj@img_process[[i]])))){
      set2 <- which(obj@img_process[[i]]==j,arr.ind = T)
      res0 = rbind(res0, cbind(j,dim(set2)[1],max(obj@img[[i]][set2]-obj@otsu_thres[[i]]))) ## difference between intensity and background

    }
    res0 = data.frame(res0)
    names(res0) = c("watershed_group","number_of_pixels","max_diff_from_threshold")
    obj@res[[i]] <- res0
  }
  return(obj)
}

clus_break_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@completed[[i]])!=0){
      next
    }
    if (length(obj@res[[i]]$watershed_group)==0){
      obj@iso_clus[[i]] = list()
      next
    }
    obj@iso_clus[[i]] = list()
    for (j in 1:length(obj@res[[i]]$watershed_group)){
      obj@iso_clus[[i]][[j]] <- iso_clus_img.LoST(obj@img_process[[i]], obj@img[[i]], obj@res[[i]]$watershed_group[j])
    }
    # obj@iso_clus[[i]] <- lapply(1:length(obj@res[[i]]$watershed_group),function(x) {iso_clus_img.LoST(obj = obj@img_process[[i]], obj2 = obj@img[[i]], ii = obj@res[[i]]$watershed_group[x])})
  }
  return(obj)
}

# f2_clus_break_img.LoST <- function(i, obj = obj){
#   if (length(obj@completed[[i]])!=0){
#     # next
#     return()
#   }
#   if (length(obj@res[[i]]$watershed_group)==0){
#     # obj@iso_clus[[i]] = list()
#     # next
#     return(list())
#   }
#   # obj@iso_clus[[i]] = list()
#   # for (j in 1:length(obj@res[[i]]$watershed_group)){
#   #   obj@iso_clus[[i]][[j]] <- iso_clus_img.LoST(obj@img_process[[i]], obj@img[[i]], obj@res[[i]]$watershed_group[j])
#   # }
#   return(lapply(1:length(obj@res[[i]]$watershed_group),function(x) {iso_clus_img.LoST(obj = obj@img_process[[i]], obj2 = obj@img[[i]], ii = obj@res[[i]]$watershed_group[x])}))
# }

is_circular.LoST <- function(obj, radius_cv = 0.11, radius_roundness0 = 0.92, radius_var1 = 1.7, px_clus_ratio=0.35){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@is_one_tree[[i]] <- list()
    for (j in 1:length(obj@radius3_var[[i]])){
      if (is.na(obj@radius3_var[[i]][[j]])){
        obj@is_one_tree[[i]][[j]] <- c(1)

        # obj@iso_clus3[[i]][[j]] = NA
        # obj@clus_center3[[i]][[j]] = NA
        # obj@clus_count3[[i]][[j]] = NA
        # record0 = c(record0,j)
        next
      }
      # if (obj@radius3_cv[[i]][[j]] > radius_cv & obj@radius3_roundness[[i]][[j]] < radius_roundness0){
      if (obj@radius3_cv[[i]][[j]] > radius_cv | (obj@radius3_roundness[[i]][[j]] < radius_roundness0 && obj@radius3_var[[i]][[j]] > radius_var1) | (obj@clus_size[[i]][[j]]/obj@base_px[[1]])>px_clus_ratio){
        obj@is_one_tree[[i]][[j]] <- 0
      }
      else{
        obj@is_one_tree[[i]][[j]] <- 1
      }
    }
  }
  return(obj)
}


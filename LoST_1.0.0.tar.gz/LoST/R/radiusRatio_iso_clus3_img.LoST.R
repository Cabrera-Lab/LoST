radiusRatio_iso_clus3_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@clus_radiuRatio[[i]] <- list()
    for (j in 1:length(obj@edge_iso_clus3[[i]])){
      center0 = obj@clus_center[[i]][[j]][rep(1, each = dim(obj@edge_iso_clus3[[i]][[j]])[1]), ]
      obj@clus_radiuRatio[[i]][[j]] = sqrt((obj@edge_iso_clus3[[i]][[j]]$row - center0$row)^2 + (obj@edge_iso_clus3[[i]][[j]]$col - center0$col)^2)  ## radius from center to edge
      obj@clus_radiuRatio[[i]][[j]] = sd(obj@clus_radiuRatio[[i]][[j]]) / mean(obj@clus_radiuRatio[[i]][[j]])   ## radius ratio i.e., sd/mean
    }
  }
  return(obj)
}

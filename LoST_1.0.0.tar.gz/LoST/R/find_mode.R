find_mode <- function(x) {
  u0 <- unique(x)
  tab0 <- tabulate(match(x, u0))
  u0[tab0 == max(tab0)]
}

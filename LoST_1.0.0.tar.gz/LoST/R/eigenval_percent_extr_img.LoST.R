eigenval_percent_extr_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@clus_eigenRatio[[i]] <- list()
    for (j in 1:length(obj@iso_clus[[i]])){
      if (length(dim(obj@iso_clus[[i]][[j]]$save_pos0)[1])==0){
        obj@clus_eigenRatio[[i]][[j]] = NA
        next
      } else if (dim(obj@iso_clus[[i]][[j]]$save_pos0)[1]==1){
        obj@clus_eigenRatio[[i]][[j]] = NA
        next
      }
      obj@clus_eigenRatio[[i]][[j]] <- min(eigen(cov(obj@iso_clus[[i]][[j]]$save_pos0))$value)/max(eigen(cov(obj@iso_clus[[i]][[j]]$save_pos0))$value) ## eigen value ratio
    }
  }
  return(obj)
}

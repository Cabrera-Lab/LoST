# Comments:   Create class "LoST" and define methods
#
# Requires:
#
# Date          Developer                                           Action
# *****************************************************************************
# 11/29/2021    Lin, C.P., Davit, S., Duan, Y., Cabrera, J.         Created
# 12/26/2021    Davit: changes based on Ben's 12/16/2021 version
# 03/24/2022    Lin                                                 Finalized
# *****************************************************************************


## -----------------------------------------------------------------------------------------------
# Define class "LoST"----
setClass(Class = "LoST",
         slots = list(img = "list",
                      raw_img = "list",
                      img_process = "list",
                      meta = "data.table",
                      name_img = "list",
                      num_img = "numeric",
                      # tree = "rpart",
                      count = "list",
                      spot_pos = "list",
                      attribute = "list",
                      directory = "character",
                      res = "list",
                      series = "list",
                      trim = "list",
                      iso_clus = "list",  ## in image (matrix) format
                      iso_clus2 = "list",  ## in coordinate format
                      clus_edge = "list",
                      clus_center = "list",
                      clus_radiuRatio = "list",
                      clus_eigenRatio = "list",
                      clus_cor_edge = "list",
                      clus_size = "list",
                      is_one_tree = "list",
                      clus_multilayer = "list",
                      clus_count = "list",
                      clus_center2 = "list",
                      completed = "list",
                      final_res = "list",
                      base_px = "list",
                      px_ratio = "list",
                      avg_spot_size = "list",
                      sd_spot_size = "list",
                      coverage_data_base1 = "data.frame",
                      coverage_data_base2 = "data.frame",
                      overlap_db = "data.frame",
                      biased = "list",
                      est_res = "data.frame",
                      iso_clus3 = "list",
                      tolerance1 = "list",
                      clus_center3 = "list",
                      edge_iso_clus3 = "list",
                      otsu_thres = "list",
                      edge_iso_clus3_backup = "list",
                      radius3 = "list",
                      radius3_var = "list",
                      radius3_cv = "list",
                      clus_count3 = "list",
                      is_GMM = "list",
                      radius3_roundness = "list",
                      skewness = "list",
                      clus_correct = "list",
                      center_offset = "list",
                      well_diameter = "list"
         ),
         prototype = list(img = list(),
                          raw_img = list(),
                          img_process = list(),
                          meta = data.table(),
                          name_img = list(),
                          num_img = numeric(),
                          # tree = NULL,
                          count = list(),
                          spot_pos = list(),
                          attribute = list(),
                          directory = character(),
                          res = list(),
                          series = list(),
                          trim = list(),
                          iso_clus = list(),
                          iso_clus2 = list(),
                          clus_edge = list(),
                          clus_center = list(),
                          clus_radiuRatio = list(),
                          clus_eigenRatio = list(),
                          clus_cor_edge = list(),
                          clus_size = list(),
                          is_one_tree = list(),
                          clus_multilayer = list(),
                          clus_count = list(),
                          clus_center2 = list(),
                          completed = list(),
                          final_res = list(),
                          base_px = list(),
                          px_ratio = list(),
                          avg_spot_size = list(),
                          sd_spot_size = list(),
                          coverage_data_base1 = data.frame(),
                          coverage_data_base2 = data.frame(),
                          overlap_db = data.frame(),
                          biased = list(),
                          est_res = data.frame(),
                          iso_clus3 = list(),
                          tolerance1 = list(),
                          clus_center3 = list(),
                          edge_iso_clus3 = list(),
                          otsu_thres = list(),
                          edge_iso_clus3_backup = list(),
                          radius3 = list(),
                          radius3_var = list(),
                          radius3_cv = list(),
                          clus_count3 = list(),
                          is_GMM = list(),
                          radius3_roundness = list(),
                          skewness = list(),
                          clus_correct = list(),
                          center_offset = list(),
                          well_diameter = list()
         ))


## -----------------------------------------------------------------------------------------------
setMethod(f = "plot",
          signature = signature(x = "LoST",
                                y = "missing"),

          definition = function(x,
                                img_num = NA,
                                overlay = FALSE,
                                plot_plate = FALSE,
                                plate_name = NA) {
            plot_img.LoST(obj = x,
                          img_num = img_num,
                          overlay = overlay,
                          plot_plate = plot_plate,
                          plate_name = plate_name)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "check",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "check",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            check_data(obj@meta)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "get_img",
           def = function(obj, dr,...) return(NULL)
)

setMethod(f = "get_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, dr) {
            get_img.LoST(obj,dr=dr)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "get_meta",
           def = function(obj, file,...) return(NULL)
)

setMethod(f = "get_meta",
          signature = signature(obj = "LoST"),
          definition = function(obj, file) {
            get_meta.LoST(obj,file=file)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "get_tree",
           def = function(obj, file,...) return(NULL)
)

setMethod(f = "get_tree",
          signature = signature(obj = "LoST"),
          definition = function(obj, file) {
            get_tree.LoST(obj,file=file)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "get_data_base",
           def = function(obj, file,...) return(NULL)
)

setMethod(f = "get_data_base",
          signature = signature(obj = "LoST"),
          definition = function(obj, file) {
            get_data_base.LoST(obj,file=file)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "get_overlap_database",
           def = function(obj, file,...) return(NULL)
)

setMethod(f = "get_overlap_database",
          signature = signature(obj = "LoST"),
          definition = function(obj, file) {
            get_overlap_database.LoST(obj,file=file)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "group",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "group",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            group.LoST(obj)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "contrast_blur_img",
           def = function(obj, size, sigma,...) return(NULL)
)

setMethod(f = "contrast_blur_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, size = round(510/10), sigma = 1) {
            contrast_blur_img.LoST(obj,size = size, sigma = sigma)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "trim_img",
           def = function(obj, diameter, h_offset0, v_offset0,...) return(NULL)
)

setMethod(f = "trim_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, diameter, h_offset0,v_offset0) {
            trim_img.LoST(obj,diameter=diameter, h_offset0=h_offset0,v_offset0=v_offset0)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "trim2_img",
           def = function(obj, diameter, h_offset0, v_offset0,...) return(NULL)
)

setMethod(f = "trim2_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, diameter, h_offset0,v_offset0) {
            trim2_img.LoST(obj,diameter=diameter, h_offset0=h_offset0,v_offset0=v_offset0)
          })

## -----------------------------------------------------------------------------------------------
setGeneric(name = "otsu_img",
           def = function(obj ,...) return(NULL)
)

setMethod(f = "otsu_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            otsu_img.LoST(obj)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "watershed_nor_img",
           def = function(obj, tolerance,...) return(NULL)
)

setMethod(f = "watershed_nor_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, tolerance = 1) {
            watershed_nor_img.LoST(obj,tolerance=tolerance)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "watershed_clus_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "watershed_clus_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            watershed_clus_img.LoST(obj)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "denoise_img",
           def = function(obj, denoise_size, diff0, ...) return(NULL)
)

setMethod(f = "denoise_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, denoise_size, diff0) {
            denoise_img.LoST(obj, denoise_size = denoise_size, diff0 = diff0)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "extreme_case_img",
           def = function(obj, uncount_px_ratio, ...) return(NULL)
)

setMethod(f = "extreme_case_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, uncount_px_ratio = 0.35) {
            extreme_case2_img.LoST(obj, uncount_px_ratio=uncount_px_ratio)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "clus_break_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "clus_break_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            clus_break_img.LoST(obj)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "radius3_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "radius3_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            radius3_img.LoST(obj)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "iso_clus2_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "iso_clus2_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            iso_clus2_img.LoST(obj)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "edge_extr_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "edge_extr_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            edge_extr_img.LoST(obj)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "center_extr_img_NEW",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "center_extr_img_NEW",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            center_extr_img_NEW.LoST(obj)
          })

## -----------------------------------------------------------------------------------------------
setGeneric(name = "refine_watershed2_img",
           def = function(obj, tol0, radius_cv, radius_var1, radius_roundness0,px_clus_ratio, ...) return(NULL)
)

setMethod(f = "refine_watershed2_img",
          signature = signature(obj = "LoST"),
          definition = function(obj,tol0 = c(0.15,0.125,0.1,0.05,0.04,0.03,0.02),radius_cv = 0.11,radius_var1=1.7,radius_roundness0 = 0.92,px_clus_ratio=0.35) {
            refine_watershed2_img.LoST(obj, tol0 = tol0, radius_cv = radius_cv,radius_var1 = radius_var1,radius_roundness0 = radius_roundness0,px_clus_ratio=px_clus_ratio)
          })

## -----------------------------------------------------------------------------------------------
setGeneric(name = "edge_iso_clus3_save_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "edge_iso_clus3_save_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            edge_iso_clus3_save_img.LoST(obj)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "skewness_radius3",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "skewness_radius3",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            skewness_radius3.LoST(obj)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "radiusRatio_extr_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "radiusRatio_extr_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            radiusRatio_extr_img.LoST(obj)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "eigenval_percent_extr_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "eigenval_percent_extr_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            eigenval_percent_extr_img.LoST(obj)
          })



## -----------------------------------------------------------------------------------------------
setGeneric(name = "abs_cor_extr_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "abs_cor_extr_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            abs_cor_extr_img.LoST(obj)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "size_extr_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "size_extr_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            size_extr_img.LoST(obj)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "is_circular",
           def = function(obj,radius_cv,radius_roundness0,radius_var1,px_clus_ratio, ...) return(NULL)
)

setMethod(f = "is_circular",
          signature = signature(obj = "LoST"),
          definition = function(obj, radius_cv = 0.11,radius_roundness0 = 0.92, radius_var1=1.7,px_clus_ratio=0.35) {
            is_circular.LoST(obj,radius_cv = radius_cv, radius_roundness0 = radius_roundness0,radius_var1=radius_var1, px_clus_ratio=px_clus_ratio)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "stratify_img",
           def = function(obj, skewness0, ...) return(NULL)
)

setMethod(f = "stratify_img",
          signature = signature(obj = "LoST"),
          definition = function(obj, skewness0 = 0.5) {
            stratify_img.LoST(obj, skewness0 = skewness0)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "count_GMM_img",
           def = function(obj,itmax, sub_portion, GMmodel,seed_num,k0, ...) return(NULL)
)

setMethod(f = "count_GMM_img",
          signature = signature(obj = "LoST"),
          definition = function(obj,itmax=300000,sub_portion=10, GMmodel = c("EII","VII"),seed_num=1992,k0=5) {
            count_GMM_img.LoST(obj, itmax=itmax,sub_portion = sub_portion, GMmodel = GMmodel,seed_num=seed_num,k0=k0)
          })

## -----------------------------------------------------------------------------------------------
setGeneric(name = "iso_clus3_img_new",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "iso_clus3_img_new",
          signature = signature(obj = "LoST"),
          definition = function(obj, itmax = 300000, sub_portion = 10, GMmodel = c("EII","VII"), seed_num = 1992) {
            iso_clus3_img_new.LoST(obj,
                                   itmax = itmax,
                                   sub_portion = sub_portion,
                                   GMmodel = GMmodel,
                                   seed_num = seed_num)
          })




## -----------------------------------------------------------------------------------------------
setGeneric(name = "extr_avg_spot_size",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "extr_avg_spot_size",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            extr_avg_spot_size.LoST(obj)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "correct_by_size_img",
           def = function(obj,size_factor, ...) return(NULL)
)

setMethod(f = "correct_by_size_img",
          signature = signature(obj = "LoST"),
          definition = function(obj,size_factor=4) {
            correct_by_size_img.LoST(obj,size_factor = size_factor)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "iso_clus3_img",
           def = function(obj,itmax, sub_portion, GMmodel,seed_num, ...) return(NULL)
)

setMethod(f = "iso_clus3_img",
          signature = signature(obj = "LoST"),
          definition = function(obj,itmax=3,sub_portion=3, GMmodel = "EII",seed_num=1992) {
            iso_clus3_img.LoST(obj, itmax=itmax,sub_portion = sub_portion, GMmodel = GMmodel,seed_num=seed_num)
          })

## -----------------------------------------------------------------------------------------------
setGeneric(name = "edge_iso_clus3_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "edge_iso_clus3_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            edge_iso_clus3_img.LoST(obj)
          })

## -----------------------------------------------------------------------------------------------

setGeneric(name = "radiusRatio_iso_clus3_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "radiusRatio_iso_clus3_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            radiusRatio_iso_clus3_img.LoST(obj)
          })

## -----------------------------------------------------------------------------------------------

setGeneric(name = "abs_cor_iso_clus3_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "abs_cor_iso_clus3_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            abs_cor_iso_clus3_img.LoST(obj)
          })

## -----------------------------------------------------------------------------------------------

setGeneric(name = "iso_clus2_for3_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "iso_clus2_for3_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            iso_clus2_for3_img.LoST(obj)
          })

## -----------------------------------------------------------------------------------------------
setGeneric(name = "display_circle_iso_clus3_img",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "display_circle_iso_clus3_img",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            display_circle_iso_clus3_img.LoST(obj)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "prep_attri",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "prep_attri",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            prep_attri.LoST(obj)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "prep_res",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "prep_res",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            prep_res.LoST(obj)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "prep_final_res",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "prep_final_res",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            prep_final_res.LoST(obj)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "correct",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "correct",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            correct.LoST(obj)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "censoring",
           def = function(obj,res0_sim, ...) return(NULL)
)

setMethod(f = "censoring",
          signature = signature(obj = "LoST"),
          definition = function(obj,res0_sim) {
            censoring2.LoST(obj,res0_sim=res0_sim)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "prep_series",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "prep_series",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            prep_series.LoST(obj)
          })


## -----------------------------------------------------------------------------------------------
setGeneric(name = "lambda.est_JLE",
           def = function(obj, ...) return(NULL)
)

setMethod(f = "lambda.est_JLE",
          signature = signature(obj = "LoST"),
          definition = function(obj) {
            lambda.est_JLE.LoST(obj)
          })


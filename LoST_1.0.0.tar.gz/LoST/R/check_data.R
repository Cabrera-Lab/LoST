#check obj@final_res:
check_data<- function(info){
  error = FALSE
  error.mess = NULL
  plate.num = unique(info$plate)
  num_plate = length(plate.num)
  
  for (i in 1:num_plate) {
    sample.num = unique(info[info$plate == i,]$`sample number`)
    num_samp = length(sample.num)
    for (j in 1:num_samp) {
      info_samp = info[which(info$plate == i & info$`sample number`==j),]
      if(length(unique(info_samp$dilution_factor)) >1 ){
        error = TRUE
        error.mess = paste("The dilution factor should be the same for the neat sample",j,"in the plate",i)
        break
      }
      rep.num = unique(info_samp$replicate)
      num_rep = length(rep.num)
      for (k in 1:num_rep ) {
        info_rep = info[which(info$plate == i & info$`sample number`==j & info$replicate == k),]
        if(length(unique(info_rep$`sampling proportion (s)`)) >1 ){
          error = TRUE
          error.mess = paste("The sampling proportion should be the same for the replicate",k, " of neat sample",j,"in the plate",i)
          break
        }
      }
    }
  }
  return(c(error,error.mess))
}
# if(check_data(info)[1]){
#   stop(check_data(info)[2])
# }
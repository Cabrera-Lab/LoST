# DS, 12/25/2021
get_meta.LoST <- function(obj,
                          file){
  obj@meta <- fread(file = file)
  return(obj)

  # instead of reassigning to the same object, try to update the input object:
  # obj <<- obj
  # or see this:
  # https://stackoverflow.com/questions/15497947/call-by-reference-in-r-using-function-to-modify-an-object
}


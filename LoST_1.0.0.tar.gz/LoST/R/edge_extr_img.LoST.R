edge_extr_img.LoST <- function(obj){
  ## filtering matrix
  # fhi = matrix(-1, nrow = 3, ncol = 3)
  # fhi[2, 2] = 8

  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@clus_edge[[i]] <- list()
    for (j in 1:length(obj@iso_clus[[i]])){
      # obj@clus_edge[[i]][[j]] <- filter2(obj@iso_clus[[i]][[j]], fhi)
      # obj@clus_edge[[i]][[j]] <- data.frame(which(obj@clus_edge[[i]][[j]]>0.9,arr.ind = T))
      set1 <- which(obj@iso_clus[[i]][[j]]>0,arr.ind = T)
      obj@clus_edge[[i]][[j]] <- data.frame(concaveman::concaveman(set1,concavity = 1))
      names(obj@clus_edge[[i]][[j]]) = c("row", "col")
    }
  }
  return(obj)
}


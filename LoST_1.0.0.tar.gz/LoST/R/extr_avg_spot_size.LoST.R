extr_avg_spot_size.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      obj@avg_spot_size[[i]] <- NA
      obj@sd_spot_size[[i]] <- NA
      next
    }
    k <- which(obj@is_one_tree[[i]]==1)  ## extract the clusters which are classified as one spot only
    if (length(k)==0){ ## the case where there is no
      obj@avg_spot_size[[i]] <- NA
      obj@sd_spot_size[[i]] <- NA
      next
    }
    temp_diameter0 <- 2*sqrt(unlist(obj@clus_size[[i]][k])/pi)
    obj@avg_spot_size[[i]] <- max(temp_diameter0)  ## calculate the spot size (in diameter) by taking the mean
    obj@sd_spot_size[[i]] <- sd(temp_diameter0)  ## calculate the sd of spot size in diameter
  }

  ## to update the average spot size if there are more diluted sample
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    index0 <- obj@meta$group_index[match(names(obj@img)[i],obj@meta$image_name)]
    temp0 <- obj@meta[obj@meta$group_index==index0,]
    temp0_size <- obj@avg_spot_size

    ## choose the most dilute sample which is non-empty
    temp0_size[sapply(temp0_size, is.null)] <- NA
    temp0$avg_spot_size = unlist(temp0_size[match(temp0$image_name,names(obj@img))])
    temp0 <- temp0[order(temp0$`dilution number`,decreasing = T),]
    obj@avg_spot_size[[i]] <- temp0$avg_spot_size[which(!is.na(temp0$avg_spot_size))[1]]
    obj@sd_spot_size[[i]] <- obj@sd_spot_size[[match(temp0$image_name[which(!is.na(temp0$avg_spot_size))[1]],obj@meta$image_name)]]
  }
  return(obj)
}

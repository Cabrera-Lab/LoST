edge3_adjacent_modelBased_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    interest0 = which(obj@is_GMM[[1]]==1)   ## cluster of interest (those cannot meet circularity check after watershed refinement)

    choices<-choose(length(obj@edge_iso_clus3[[i]]),2)
    combs<-combn(length(obj@edge_iso_clus3[[i]]),2)
    for(k in 1:choices) {
      # print(k)
      pair<-c(combs[1,k], combs[2,k])
      if (any(pair %in% interest0)){
        A = obj@edge_iso_clus3[[i]][[pair[1]]]
        B = obj@edge_iso_clus3[[i]][[pair[2]]]
        euklDist <- sqrt(apply(array(apply(B,1,function(x){(x-t(A))^2}),c(ncol(A),nrow(A),nrow(B))),2:3,sum)) ## calculate the euclidean distance in a pairwise manner

        set2 = which(euklDist<=sqrt(2),arr.ind = T)
        # set2[1,"row"] ## row; A
        # set2[1,"col"] ## col; B
        if (length(set2)!=0){
          obj@edge_iso_clus3[[i]][[pair[1]]] = A[-set2[,"row"],] ## edge without common edge, for cluster A
          obj@edge_iso_clus3[[i]][[pair[2]]] = B[-set2[,"col"],] ## edge without common edge, for cluster B
        }
      }
    }
  }
  return(obj)
}






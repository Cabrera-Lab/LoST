PhageImage_gen <- function(
    s0 = 50,  ## how many phages to be simulated
    k0 = 1,  ## how many replications
    d1 = 500,  ## the diameter of the wells, default is 500
    bg_intensity = 0.75 ## general intensity of the background
    ,bg_noise0 = 50  ## background noise level, "divisor" parameter for an AR(0) noise
    ,d2o = 42  ## the general size of small circle; d2 is the size with uncertainty
    ,df0_circle_size = 500   ## degree of freedom of chi-square   #200 was used in early trial
    ,mix0 = F  ## whether to simulate phages with mixed sizes
    ,mix0_range = c(20,40,60) ## specifying the range of the mixed sizes of phages
    # ,shape0 = 10 ## "divisor" parameter to divide the size of small circle (d2), to determine what portion of "density peak" (from the top) is used as the intensity of small circle
    ## new version: normalize any size of circle to [-2,2] so as to get the pdf (intensity) from mvtnorm
    ,var0 = 5  ## variance of the bivariate Gaussian (small circle)
    ,cov0 = 0  ## covariance of the bivariate Gaussian (small circle)
    # df0_circle_intensity = 4000 ## degree of freedom of chi-squar, did not use, use bg_noise0 instead
    ,divi_intensity_range0 = 5  ## control the range of intensity of small circle (regardless of the background intensity)
    ,d3 = 395  ## the diameter that phages appear inside a 500x500 pixels well
    ,blur_sig0 = 5  ## sd of gaussian filter to blur the image
    ,blur_radius0 = 3  ## radius of the filter
    ,offset_row0 = 0 ## offset the entire phage area within the well (row)
    ,offset_col0 = 0 ## offset the entire phage area within the well (col)
    , seed0=1992){

  if (sqrt(offset_row0^2+offset_col0^2) > ((d1-d3)/2)){
    stop("offset is out of bound.\n sqrt(offset_row0^2+offset_col0^2) should be smaller than ((d1-d3)/2)")
  }
  if (mix0 == T){
    print(paste(c("The values of mixed size are ", mix0_range),collapse = ","))
  }

  for (sim_size0 in c(seq(s0,s0,by = 10))){   ## how many phages to be simulated
    set.seed(seed0)
    sim0=NULL
    for (k in 1:k0){
      mm1 <- matrix(rep((1:d1 - d1/2)^2, d1),
                    ncol = d1,
                    byrow = TRUE)
      mm_sim <- sqrt(mm1 + t(mm1))
      sett0 <- which(mm_sim <= d1/2, arr.ind = TRUE)
      sett1 <- which(mm_sim > d1/2, arr.ind = TRUE)
      sett0_temp <- which(mm_sim <= d1/2, arr.ind = TRUE)
      sett1_temp <- which(mm_sim > d1/2, arr.ind = TRUE)

      mm_bin_all = mm_sim
      mm_bin_temp = mm_sim

      mm_sim[sett0] = as.numeric(bg_intensity + arima.sim(model = list(), n = length(mm_sim[sett0]))/bg_noise0)  ## background intensity , with white noise: AR(0)
      mm_sim[sett1] = 1  ## the four corner of the square, it is white color in the original image, so put it 1

      mm_sim_temp = mm_sim
      mm_sim_temp = gblur(mm_sim_temp,sigma = blur_sig0,radius = blur_radius0)
      mm_sim_temp[sett1_temp] = NA

      well_intensity_for_bin = max(mm_sim_temp,na.rm = T)
      # well_intensity_for_bin = quantile(mm_sim_temp,probs = 0.99,na.rm = T)
      # well_intensity_for_bin = Mode0(mm_sim_temp,na.rm = T)

      # mm_sim_temp[sett1_temp] = 0
      # browser()

      mm_bin_all[sett1] = NA  ## four corners
      mm_bin_all[sett0] = 0   ## the background circle

      mm_bin_temp[sett1] = NA  ## four corners
      mm_bin_temp[sett0] = 0   ## the background circle

      ## sample center points
      m1 <- matrix(rep((1:d1 - d1/2)^2, d1),
                   ncol = d1,
                   byrow = TRUE)
      mm <- sqrt(m1 + t(m1))
      set0 <- which(mm <= d1/2, arr.ind = TRUE)  ## this includes all the points in a big circle (background)

      ## discard points that fall outside of the diameter "d3"
      set0 = set0[-which(sqrt((set0[,1]-(d1/2))^2+(set0[,2]-d1/2)^2) > (d3/2)),]
      set0 = data.frame(set0)

      sim_center0_all = NULL
      count1 = 0
      record_bin = NULL  ## record the individual "observed" spot and build the entire phage binary map at last

      mm_bin_no_noise = mm_bin_temp
      for (j in 1:sim_size0){
        if (dim(set0)[1]==0){
          print("number of phages simulated exceeds the pixels of well")
          break
        }
        sample0 = sample(1:dim(set0)[1],size = 1)
        sim_center0 = set0[sample0,]
        # sim_center0 = data.frame(t(sim_center0))
        sim_center0$row = sim_center0$row + offset_row0
        sim_center0$col = sim_center0$col + offset_col0

        #### make small circles
        if (mix0 == T){
          d2o = sample(mix0_range,size = 1)
        }
        d2 = round(d2o * rchisq(1,df = df0_circle_size)/df0_circle_size)  ## impose uncertainty in the diameter of small circles by chi-square
        m11 <- matrix(rep(((1:d2 - d2/2))^2, d2),
                      ncol = d2,
                      byrow = TRUE)
        mmm <- sqrt(m11 + t(m11))
        set00 <- which(mmm <= d2/2, arr.ind = TRUE)
        set00 = set00 - ceiling(d2/2)  ## align the small circle to be centered at origin, i.e., (0,0) , ceiling() is for odd d2

        # set00x = set00/shape0 ## parameter to adjust the spread of small circle
        set00x = set00
        set00x[,1] = normalize2(set00[,1])
        set00x[,2] = normalize2(set00[,2])


        u0 <- as.list(as.data.frame(t(matrix(data = 0,nrow = nrow(set00x),ncol = 2))))
        cov_mat0 = diag(2)*var0
        cov_mat0[c(2,3)] = c(cov0,cov0)  ## covariance in the covariance matrix of bivariate Gaussian
        sigma0 <- rep(list(cov_mat0),nrow(set00x))  ## parameter to adjust the spread of small circle
        x0 <- as.list(as.data.frame(t(matrix(set00x,ncol = 2))))
        result <- mapply(dmvnorm, x0, u0, sigma0) ## mapply for dmvnorm(x0[[1]],u0[[1]],sigma0[[1]])

        ly=NULL
        ly$Row=set00[,1]
        ly$Column = set00[,2]
        ly$Intensity = normalize0(result)

        ly$Intensity = ly$Intensity/divi_intensity_range0 + bg_intensity + as.numeric(arima.sim(model = list(), n = length(ly$Intensity))/bg_noise0)   ## need to be consistently adjusted with the above parameter to adjust the spread of small circle
        ly = data.frame(ly)

        #######
        set00[,1] = set00[,1] + sim_center0$row
        set00[,2] = set00[,2] + sim_center0$col

        ## place the small circle over the well circle
        mm_bin = mm_bin_temp

        ## provide a black background for recording each individual spot
        mm_sim_clean = mm_bin_temp



        for (i in 1:nrow(set00)){
          if (mm_sim[set00[i,1],set00[i,2]] < ly$Intensity[i]){
            arima_temp0 = arima.sim(model = list(), n = 1)/50  ## noise
            mm_sim[set00[i,1],set00[i,2]] = ly$Intensity[i] + arima_temp0

            ## make the binary segmentation (or binary map)
            # mm_sim_clean[set00[i,1],set00[i,2]] = ly$Intensity[i] + arima_temp0
          }
          ## make the binary segmentation (or binary map)
          mm_bin_no_noise[set00[i,1],set00[i,2]] = 1
          mm_sim_clean[set00[i,1],set00[i,2]] = 1
        }
        count1 = count1 + 1

        ## capture only the spot portion where its intensity is higher than the background intensity
        set_new_temp = which(mm_sim_clean<1,arr.ind = T)
        mm_sim_clean = mm_sim
        # browser()
        mm_sim_clean = gblur(mm_sim_clean,sigma = blur_sig0,radius = blur_radius0)
        mm_sim_clean[set_new_temp] = 0
        set_indiv_temp = which(mm_sim_clean>well_intensity_for_bin,arr.ind = T)
        set_indiv_temp2 = which(mm_sim_clean<=well_intensity_for_bin,arr.ind = T)
        mm_bin[set_indiv_temp] = 1
        mm_bin[set_indiv_temp2] = 0

        mm_sim_clean = mm_bin_temp

        record_bin = rbind(record_bin,set_indiv_temp)

        ## save each spot as a unique class
        # assign(x = paste0("mm_bin_class",as.character(seed_df0[row0,"X.1"]), seed_df0[row0,"col0"],"_",count1),value = mm_bin,envir = .GlobalEnv)

        ##### blur
        mm_gblur <- gblur(mm_sim,sigma = blur_sig0,radius = blur_radius0)

        set0 = set0[-sample0,]

        sim_center0_all = rbind(sim_center0_all, sim_center0)
      }
      print(k)

      ## make the binary segmentation (or binary map)
      ## capture only the spot portion where its intensity is higher than the background intensity
      # set_temp = which(mm_sim>well_intensity_for_bin,arr.ind = T)
      # set_temp2 = which(mm_sim<=well_intensity_for_bin,arr.ind = T)
      mm_bin_all[record_bin] = 1
      # mm_bin_all[set_temp2] = 0
      ## save all the spot together as one class
      # assign(x = paste0("mm_bin_all",as.character(seed_df0[row0,"X.1"]), seed_df0[row0,"col0"],"_",count1),value = mm_bin_all,envir = .GlobalEnv)
      #
      # assign(x = paste0("NO_NOISE_mm_bin_all",as.character(seed_df0[row0,"X.1"]), seed_df0[row0,"col0"],"_",count1),value = mm_bin_no_noise,envir = .GlobalEnv)

    }
    print(paste("#################   number of phages: ",    sim_size0))
  }
  sim_center0_all <<- sim_center0_all
  mm_gblur
}


normalize0 <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}
normalize2 <- function(x) {
  return (4*(x - min(x)) / (max(x) - min(x))-2)
}

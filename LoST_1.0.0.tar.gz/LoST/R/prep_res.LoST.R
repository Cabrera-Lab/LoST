prep_res.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      obj@count[[i]]=0
      obj@spot_pos[[i]] = NA
      next
    }
    obj@count[[i]] <- sum(matrix(unlist(obj@clus_count3[[i]]), nrow=length(obj@clus_count3[[i]]),byrow = T)[,1])
    obj@spot_pos[[i]] <- Reduce(function(x,y) merge(x,y,all=T),obj@clus_center[[i]])  ## merge in an accumulative manner
    obj@completed[[i]] = 1
  }
  names(obj@spot_pos) <- names(obj@img)
  return(obj)
}






edge_iso_clus3_save_img.LoST <- function(obj){
  ## filtering matrix
  # fhi = matrix(-1, nrow = 3, ncol = 3)
  # fhi[2, 2] = 8

  for (i in 1:length(obj@img_process)){
    obj@edge_iso_clus3_backup[[i]] <- list()
    if (length(obj@iso_clus[[i]])==0){
      next
    }

    for (j in 1:length(obj@iso_clus[[i]])){
      # obj@edge_iso_clus3[[i]][[j]] <- filter2(obj@iso_clus3[[i]][[j]], fhi)
      # obj@edge_iso_clus3[[i]][[j]] <- data.frame(which(obj@edge_iso_clus3[[i]][[j]]>0.9,arr.ind = T))

      # set1 <- which(obj@iso_clus3[[i]][[j]]>0,arr.ind = T)
      obj@edge_iso_clus3_backup[[i]][[j]] <- data.frame(concaveman::concaveman(obj@iso_clus[[i]][[j]]$save_pos0,concavity = 1))
      names(obj@edge_iso_clus3_backup[[i]][[j]]) = c("row", "col")
    }
  }
  return(obj)
}

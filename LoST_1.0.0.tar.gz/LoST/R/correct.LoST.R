correct.LoST <- function(obj){
  obj@final_res$new_count = obj@final_res$count
  temp0 <- round(approx(obj@overlap_db$`count to be corrected`,obj@overlap_db$`expected number of overlap`,xout = obj@final_res$count)$y)
  temp0[is.na(temp0)]=0

  obj@final_res$new_count = obj@final_res$count + temp0  ## correct the count by adding the expected number of overlap (missing) in such number of count

  return(obj)
}

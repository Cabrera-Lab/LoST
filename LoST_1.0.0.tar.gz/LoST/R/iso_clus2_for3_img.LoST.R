iso_clus2_for3_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus3[[i]])==0){
      next
    }
    temp_list <- list()
    for (j in 1:length(obj@iso_clus3[[i]])){
      temp_list[[j]] <- which(obj@iso_clus3[[i]][[j]]>0,arr.ind = T)
    }
    obj@iso_clus2[[i]] <- temp_list
    }
  return(obj)
}


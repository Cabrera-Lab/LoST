
#lambda.est_JLE: method to get the estimated lambdas, i.e., the numbers of particles in the neat samples, and corresponding bootstrap CIs,  for an LoST object.
#obj: an LoST object
#nboot: the number of bootstrap samples generated for CI
#level: confidence level for bootstrap CI
#CI: If TRUE, output estimates with confidence intervals. If FLASE, only output the point estimates.

lambda.est_JLE <- function(obj,nboot = 500,level = 0.95, CI = TRUE,seed_num=1234){

  info = obj@final_res
  plate.num = unique(info$plate)
  num_plate = length(plate.num)
  set.seed(seed_num)

  result = NULL
  for (i in 1:num_plate) {
    sample.num = unique(info[info$plate == i,]$`sample number`)
    num_samp = length(sample.num)
    for (j in 1:num_samp) {
      info_samp = info[which(info$plate == i & info$`sample number`==j),]
      m = length(unique(info_samp$replicate))
      result_rep = NULL
      for (k in 1:m) {
        info_rep = info[which(info$plate == i & info$`sample number`==j & info$replicate ==k & info$disagreement == FALSE),]
        # conditions could be changed according to the result table, such as disagreement.
        data = info_rep$count
        if (all(data==0)){
          if (isTRUE(CI)){
            temp0 = as.matrix(t(c(0,0,0)))
            colnames(temp0) = c("lambda.est","bootstrap.CI_L", "bootstrap.CI_R")
            result_rep = rbind(result_rep, temp0)
          } else{
            temp0 = as.matrix(0)
            colnames(temp0) = "lambda.est"
            result_rep = rbind(result_rep, temp0)
          }
          next
        }
        d = info_rep$`dilution number`
        p = 1/info_rep$dilution_factor[1]
        s = info_rep$`sampling proportion (s)`[1]
        cen = info_rep$`censor threshold`[1] # a column indicating the censoring threshold, i.e., 120
        est = lambda.est(data,d,p,s,cen,nboot,CI,level)
        result_rep = rbind(result_rep, as.matrix(est))
      }
      result = rbind(result,c(i,j,as.matrix(colMeans(result_rep))))
    }
  }

  if(CI == TRUE){
    colnames(result) = c("plate","sample number","Lambda.est","Bootstrap.CI_L","Bootstrap.CI_R")
  }else{
    colnames(result) = c("plate","sample number","Lambda.est")
  }

  result = as.data.frame(result)

  #return(result)

  print(result)
  obj@est_res = result

  return(obj)
}

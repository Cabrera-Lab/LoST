prep_attri.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    ## prepare the attribute of the clusters: eigenRatio, correlation of cluster edge, radius ratio, size, center, clus_count
    obj@attribute[[i]] <- data.frame(cbind(unlist(obj@clus_eigenRatio[[i]]), unlist(obj@clus_cor_edge[[i]]), unlist(obj@clus_radiuRatio[[i]]), unlist(obj@clus_size[[i]]), matrix(unlist(obj@clus_center[[i]]),nrow = length(obj@clus_center[[i]]),byrow = T)))
    names(obj@attribute[[i]]) <- c("eigenRatio", "cor_edge", "radiusRatio", "size","center_row", "center_col")
  }
  return(obj)
}






#lambda.est: function to get the estimated lambda, i.e., the number of particles in the neat sample, and corresponding bootstrap CI,  for a neat sample by JLE with Poisson model.
#data: a vector of a dilution serial count data for a neat sample.
#d: a vector of dilution levels corresponding to each count data.
#p: dilution proportion, i.e, 1/dilution factor
#s: sampling proportion from tubes to wells. 
#cen: a positive integer indicating a threshold about censoring. Any counts larger than this integer would be regarded as right-censored. 
#nboot: the number of bootstrap samples generated for CI
#level: confidence level for bootstrap CI
#CI: If TRUE, output estimate with confidence interval. If FLASE, only output the point estimate.

lambda.est <- function(data,d,p,s,cen,nboot = 500,CI = TRUE,level = 0.95){
  
  if(p <=0 | p >=1){
    stop("dilution proportion p should be between 0 and 1")
  }
  if(s <= 0 | s >= 1){
    stop("sampling proportion s should be between 0 and 1")
  }
  
  if(cen %% 1 != 0 | cen <= 0){
    stop("cen should be a positive integer")
  }
  if(length(d) != length(data)){
    stop("The length of dilution numbers is not the same as the number of counts. 
         The dilution number for each count should be provided.")
  }
  
  
  
  lambda.poi = optimLambda(data,d,p,s,cen)
  if(CI ==TRUE){
    lambda.ci.boot = ci.boot(data,d,p,s,cen,nboot,level)
    result = data.frame(lambda.est = lambda.poi, bootstrap.CI_L = lambda.ci.boot[1],bootstrap.CI_R = lambda.ci.boot[2])
  }else{
    result = data.frame(lambda.est = lambda.poi)
  }
  
  return(result)
  
}
size_extr_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@clus_size[[i]] <- list()
    for (j in 1:length(obj@iso_clus[[i]])){
      if (is.null(dim(obj@iso_clus[[i]][[j]]$save_pos0))){
        obj@clus_size[[i]][[j]] <- 1
      } else{
        obj@clus_size[[i]][[j]] <-  dim(obj@iso_clus[[i]][[j]]$save_pos0)[1]  ## size of the cluster
      }
    }
  }
  return(obj)
}

#optimLambda: function to get the optimal estimated lambda, i.e., the number of particles in the neat sample, for a sample by JLE with Poisson model.
#data: a vector of a dilution serial count data for a neat sample.
#d: a vector of dilution levels corresponding to each count data.
#p: dilution proportion, i.e, 1/dilution factor
#s: sampling proportion from tubes to wells.
#cen: a positive integer indicating a threshold about censoring. Any counts larger than this integer would be regarded as right-censored.

optimLambda <- function(data,d,p,s,cen){

  if(p <=0 | p >=1){
    stop("dilution proportion p should be between 0 and 1")
  }
  if(s <= 0 | s >= 1){
    stop("sampling proportion s should be between 0 and 1")
  }

  if(cen %% 1 != 0 | cen <= 0){
    stop("cen should be a positive integer")
  }
  if(length(d) != length(data)){
    stop("The length of dilution numbers is not the same as the number of counts.
         The dilution number for each count should be provided.")
  }


  opti.poi <- function(dat,d,p,s,cen){
    q = p^d*s
    x = as.vector(dat)
    n =  as.numeric(x > cen)
    if(sum(n == 1) >0){
      cen_v = cen/p^(max(d[n==1])-d[n==1])
      x[n==1] = cen_v
    }

    loglike <- function(lambda){
      lambda_new = lambda*q
      sum_censor = sum(apply(cbind(x[n==1],lambda_new[n==1]), 1,
                             function(t) log(ppois(t[1],lambda = t[2],lower.tail = FALSE))))
      sum_uncen = sum(apply(cbind(x[n==0],lambda_new[n==0]), 1,
                            function(t) log(dpois(t[1],lambda = t[2]))))

      return(sum_censor+sum_uncen)
    }
    max_un = max(x[n==0])
    max2_un = sort(x[n==0])[length(x[n==0]) - 1]

    if (length(max2_un)==0){
      start = max_un/q[which(x == max_un)[1]]
    } else{
      start = mean(max_un/q[which(x == max_un)[1]], max2_un/q[which(x == max2_un)[1]])
    }

    est = optimize(loglike, c(start*0.5,start*2+0.0000001),maximum = TRUE)
    return(round(est$maximum))
  }


  return(round(opti.poi(data,d,p,s,cen)))
}

edge3_adjacent_img.LoST <- function(obj){
  # obj3 <<- obj
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    if (length(obj@edge_iso_clus3[[i]])==1){  ## only one cluster is identified originally
      next
    }

    choices<-choose(length(obj@edge_iso_clus3[[i]]),2)
    combs<-combn(length(obj@edge_iso_clus3[[i]]),2)

    # temp0 = obj@edge_iso_clus3[[i]]
    invisible(lapply(1:choices, f1_edge3_adjacent_img.LoST,combs=combs,obj=obj,i=i))

    obj@edge_iso_clus3[[i]] <- temp0
  }
  # obj = obj3
  # obj3 <<- NULL
  return(obj)
}

f1_edge3_adjacent_img.LoST <- function(k, combs=combs, obj = obj, i = i,e0 = e0){
  if (k == 1){
    temp0 = obj@edge_iso_clus3[[i]]
  } else{
    temp0 = e0$temp0
  }

  pair<-c(combs[1,k], combs[2,k])
  A = obj@edge_iso_clus3[[i]][[pair[1]]]
  B = obj@edge_iso_clus3[[i]][[pair[2]]]
  # browser()
  # print(A[1,])

  ## check if A and B are too far away, skip them to save time, check if range(A_row) is within range(B_row)+-1, vice versa, and for "col" as well.
  if ((any(data.table::between(range(B[,1]),lower = range(A[,1])[1]-1, upper = range(A[,1])[2]+1)) | any(data.table::between(range(A[,1]),lower = range(B[,1])[1]-1, upper = range(B[,1])[2]+1))) && (any(data.table::between(range(B[,2]),lower = range(A[,2])[1]-1, upper = range(A[,2])[2]+1)) | any(data.table::between(range(A[,2]),lower = range(B[,2])[1]-1, upper = range(B[,2])[2]+1)))){
    euklDist <- sqrt(apply(array(apply(B,1,function(x){(x-t(A))^2}),c(ncol(A),nrow(A),nrow(B))),2:3,sum)) ## calculate the euclidean distance in a pairwise manner

    set2 = which(euklDist<=sqrt(2),arr.ind = T)
    # set2[1,"row"] ## row; A
    # set2[1,"col"] ## col; B
    if (length(set2)!=0){
      # obj3@edge_iso_clus3[[i]][[pair[1]]] <<- A[-set2[,"row"],] ## edge without common edge, for cluster A
      # obj3@edge_iso_clus3[[i]][[pair[2]]] <<- B[-set2[,"col"],] ## edge without common edge, for cluster B
      temp0[[pair[1]]] <- A[-set2[,"row"],] ## edge without common edge, for cluster A
      temp0[[pair[2]]] <- B[-set2[,"col"],] ## edge without common edge, for cluster B
    }
  }
  # temp0[[k]]=k ## to test the environment issue
  assign("temp0",value = temp0,envir = e0)
  return(NULL)
}

f2_edge3_adjacent_img.LoST <- function(i, obj=obj){
  e0 <- new.env()

  if (length(obj@iso_clus[[i]])==0){
    # next
    return()
  }
  if (length(obj@edge_iso_clus3[[i]])==1){  ## only one cluster is identified originally
    # next
    return(obj@edge_iso_clus3[[i]])
  }

  choices<-choose(length(obj@edge_iso_clus3[[i]]),2)
  combs<-combn(length(obj@edge_iso_clus3[[i]]),2)

  # temp0 = obj@edge_iso_clus3[[i]]
  invisible(lapply(1:choices, f1_edge3_adjacent_img.LoST,combs=combs,obj=obj,i=i,e0=e0))

  return(e0$temp0)
}



# edge3_adjacent_img.LoST <- function(obj){
#   for (i in 1:length(obj@img_process)){
#     if (length(obj@iso_clus[[i]])==0){
#       next
#     }
#     if (length(obj@edge_iso_clus3[[i]])==1){  ## only one cluster is identified originally
#       next
#     }
#
#     choices<-choose(length(obj@edge_iso_clus3[[i]]),2)
#     combs<-combn(length(obj@edge_iso_clus3[[i]]),2)
#     for (k in 1:choices) {
#       # print(k)
#       pair<-c(combs[1,k], combs[2,k])
#       A = obj@edge_iso_clus3[[i]][[pair[1]]]
#       B = obj@edge_iso_clus3[[i]][[pair[2]]]
#
#       ## check if A and B are too far away, skip them to save time, check if range(A_row) is within range(B_row)+-1, vice versa, and for "col" as well.
#       if ((any(data.table::between(range(B[,1]),lower = range(A[,1])[1]-1, upper = range(A[,1])[2]+1)) | any(data.table::between(range(A[,1]),lower = range(B[,1])[1]-1, upper = range(B[,1])[2]+1))) && (any(data.table::between(range(B[,2]),lower = range(A[,2])[1]-1, upper = range(A[,2])[2]+1)) | any(data.table::between(range(A[,2]),lower = range(B[,2])[1]-1, upper = range(B[,2])[2]+1)))){
#         euklDist <- sqrt(apply(array(apply(B,1,function(x){(x-t(A))^2}),c(ncol(A),nrow(A),nrow(B))),2:3,sum)) ## calculate the euclidean distance in a pairwise manner
#
#         set2 = which(euklDist<=sqrt(2),arr.ind = T)
#         # set2[1,"row"] ## row; A
#         # set2[1,"col"] ## col; B
#         if (length(set2)!=0){
#           obj@edge_iso_clus3[[i]][[pair[1]]] = A[-set2[,"row"],] ## edge without common edge, for cluster A
#           obj@edge_iso_clus3[[i]][[pair[2]]] = B[-set2[,"col"],] ## edge without common edge, for cluster B
#         }
#       }
#     }
#   }
#   return(obj)
# }






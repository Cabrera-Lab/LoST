extreme_case2_img.LoST <- function(obj, uncount_px_ratio = 0.35){
  for (i in 1:length(obj@img_process)){
    if (any(obj@res[[i]]$number_of_pixels/obj@base_px[[i]]>uncount_px_ratio)){ ## situation that we cannot count, only one huge spot
      print(paste0(names(obj@img)[i]," is not countable."))
      obj@count[[i]] = NA
      obj@completed[[i]] = 1
    } else if (dim(obj@res[[i]])[1]==0){
      obj@count[[i]] = 0
      print(paste0(names(obj@img)[i], ": no cluster found"))
      obj@completed[[i]] = 1
    }
  }
  return(obj)
}

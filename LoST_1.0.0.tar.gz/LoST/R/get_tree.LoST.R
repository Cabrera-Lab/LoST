get_tree.LoST <- function(obj,
                          file){
  ## read the pre-trained data (i.e., a dataframe indicating the characteristics of belonging to one or more-than-one cluster)
  res0_tree_all <- readRDS(file = file)
  fit0 <- rpart::rpart(as.factor(is.one) ~ eigenRatio + cor_edge + radiusRatio + size, data = res0_tree_all,method="class",control = rpart::rpart.control(minsplit=1))
  obj@tree <- fit0
  return(obj)
}

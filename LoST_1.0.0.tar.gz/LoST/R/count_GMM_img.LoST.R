count_GMM_img.LoST <- function(obj, itmax=3, sub_portion=3, GMmodel = c("EII","VII"), seed_num=1992, k0=5){
  obj@clus_center2 = obj@clus_center
  # set.seed(1992)
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    # browser()
    obj@clus_count[[i]] = list()
    for (j in 1:length(obj@is_one_tree[[i]])){
      if (obj@is_one_tree[[i]][[j]]!=1){
        ### GMM
        set.seed(seed_num)
        # gmm0 <- ClusterR::Optimal_Clusters_GMM(obj@clus_multilayer[[i]][[j]],max_clusters = 10,criterion = "BIC",km_iter = 3,em_iter = 3,dist_mode = "eucl_dist",plot_data = F)
        temp0 = NULL
        for (k in 1:k0){
          if (is.na(sub_portion)){
            gmm0 <- -1*mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = 1:5,modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F)$BIC[,1]
          } else if (nrow(obj@clus_multilayer[[i]][[j]])/sub_portion <= 10){
            gmm0 <- -1*mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = 1:5,modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F)$BIC[,1]
          } else{
            gmm0 <- -1*mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = 1:5,modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F,initialization = list(subset=sample(1:nrow(obj@clus_multilayer[[i]][[j]]),size = round(nrow(obj@clus_multilayer[[i]][[j]])/sub_portion))))$BIC[,1]
          }
          temp0 = rbind(temp0, clust_sel_gmm(gmm0,jrange = 1:5,dd=2)[1:2])
        }

        # browser()
        # obj@clus_count[[i]][[j]] <- clust_sel_gmm(gmm0,jrange = 1:5,dd=2)[1:2]  ## get the first two values from the second diff method
        obj@clus_count[[i]][[j]] <- c(round(find_mode(temp0[,1]),digits = 0),round(find_mode(temp0[,2]),digits = 0))  ## get the first two values from the second diff method

        ## output the center
        if (is.na(sub_portion)){
          mod_gmm0 <- mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = obj@clus_count[[i]][[j]][1],modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F)
        } else if (nrow(obj@clus_multilayer[[i]][[j]])/sub_portion <= 10){
          mod_gmm0 <- mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = obj@clus_count[[i]][[j]][1],modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F)
        } else {
          mod_gmm0 <- mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = obj@clus_count[[i]][[j]][1],modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F,initialization = list(subset=sample(1:nrow(obj@clus_multilayer[[i]][[j]]),size = round(nrow(obj@clus_multilayer[[i]][[j]])/sub_portion))))
          if (length(mod_gmm0)==0){
            mod_gmm0 <- mclust::Mclust(obj@clus_multilayer[[i]][[j]],G = obj@clus_count[[i]][[j]][1],modelNames = GMmodel,control = emControl(itmax = rep(itmax,2)),verbose = F,initialization = list(subset=sample(1:nrow(obj@clus_multilayer[[i]][[j]]),size = round(nrow(obj@clus_multilayer[[i]][[j]])/sub_portion))))
          }
        }
        obj@clus_center2[[i]][[j]] <- data.frame(t(mod_gmm0$parameters$mean))

      } else{ ## the case in which the count of the cluster is one
        obj@clus_count[[i]][[j]] <- c(1,1)
      }
    }
  }
  return(obj)
}

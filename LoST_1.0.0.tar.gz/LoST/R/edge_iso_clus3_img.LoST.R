edge_iso_clus3_img.LoST <- function(obj){
  ## filtering matrix
  # fhi = matrix(-1, nrow = 3, ncol = 3)
  # fhi[2, 2] = 8

  for (i in 1:length(obj@img_process)){
    obj@edge_iso_clus3[[i]] <- list()
    if (length(obj@iso_clus[[i]])==0){
      next
    }

    # for (j in 1:length(obj@iso_clus3[[i]])){
    #   # obj@edge_iso_clus3[[i]][[j]] <- filter2(obj@iso_clus3[[i]][[j]], fhi)
    #   # obj@edge_iso_clus3[[i]][[j]] <- data.frame(which(obj@edge_iso_clus3[[i]][[j]]>0.9,arr.ind = T))
    #
    #   set1 <- which(obj@iso_clus3[[i]][[j]]>0,arr.ind = T)
    #   obj@edge_iso_clus3[[i]][[j]] <- data.frame(concaveman::concaveman(set1,concavity = 1))
    #   names(obj@edge_iso_clus3[[i]][[j]]) = c("row", "col")
    # }

    obj@edge_iso_clus3[[i]] <- lapply(1:length(obj@iso_clus[[i]]),f1_edge_iso_clus3_img.LoST,obj = obj, i=i)
  }
  return(obj)
}


f1_edge_iso_clus3_img.LoST <- function(j, obj = obj,i=i){
  # set1 <- which(obj@iso_clus3[[i]][[j]]>0,arr.ind = T)
  if (length(dim(obj@iso_clus[[i]][[j]]$save_pos0)[1])==0){
    temp0 = data.frame(t(obj@iso_clus[[i]][[j]]$save_pos0))
    names(temp0) = c("row", "col")
    return(temp0)
  } else {
    temp0 <- data.frame(concaveman::concaveman(obj@iso_clus[[i]][[j]]$save_pos0,concavity = 1))
    names(temp0) = c("row", "col")
    return(temp0)
  }

}

f2_edge_iso_clus3_img.LoST <- function(i, obj = obj){
  # obj@edge_iso_clus3[[i]] <- list()
  if (length(obj@iso_clus[[i]])==0){
    # next
    return()
  }
  return(lapply(1:length(obj@iso_clus[[i]]),f1_edge_iso_clus3_img.LoST,obj = obj, i=i))
}

## use convex hull method to identify edges
# edge_iso_clus3_img.LoST <- function(obj){
#   for (i in 1:length(obj@img_process)){
#     if (length(obj@iso_clus[[i]])==0){
#       next
#     }
#     obj@edge_iso_clus3[[i]] <- list()
#     for (j in 1:length(obj@iso_clus3[[i]])){
#       center0 = round(obj@clus_center3[[i]][[j]])
#
#       set1 <- which(obj@iso_clus3[[i]][[j]]>0.5,arr.ind = T)
#       # plot(set1,asp=1)
#       ## convex hull (extract edge)
#       hpts <- chull(set1)
#       hpts <- c(hpts, hpts[1])
#       # lines(set1[hpts, ])
#
#       # edge0 = set1[hpts,]
#       obj@edge_iso_clus3[[i]][[j]] <- set1[hpts,]
#
#     }
#   }
#   return(obj)
# }

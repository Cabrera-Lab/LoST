center_extr_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@clus_center[[i]] <- list()
    for (j in 1:length(obj@clus_edge[[i]])){
      obj@clus_center[[i]][[j]] <- apply(obj@clus_edge[[i]][[j]],MARGIN = 2,FUN = mean)
      obj@clus_center[[i]][[j]] <- data.frame(t(obj@clus_center[[i]][[j]]))
    }
  }
  return(obj)
}

skewness_radius3.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@skewness[[i]] <- list()
    for (j in 1:length(obj@edge_iso_clus3[[i]])){
      if (dim(unique(obj@edge_iso_clus3_backup[[i]][[j]]))[1]==1){
        obj@skewness[[i]][[j]] = 0
        next
      }
      temp0 = sqrt((obj@edge_iso_clus3_backup[[i]][[j]][,1] - obj@clus_center[[i]][[j]][,1])^2 + (obj@edge_iso_clus3_backup[[i]][[j]][,2] - obj@clus_center[[i]][[j]][,2])^2)
      if (length(unique(temp0))==1){
        obj@skewness[[i]][[j]] = 0
        next
      }
      obj@skewness[[i]][[j]] = e1071::skewness(temp0)
    }
  }
  return(obj)
}

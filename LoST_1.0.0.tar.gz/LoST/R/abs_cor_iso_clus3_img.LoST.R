abs_cor_iso_clus3_img.LoST <- function(obj){
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    obj@clus_cor_edge[[i]] <- list()
    for (j in 1:length(obj@edge_iso_clus3[[i]])){
      obj@clus_cor_edge[[i]][[j]] <- abs(cor(obj@edge_iso_clus3[[i]][[j]])[1, 2])   ## correlation of edge
    }
  }
  return(obj)
}

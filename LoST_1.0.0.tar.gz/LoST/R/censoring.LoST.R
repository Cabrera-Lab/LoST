censoring.LoST <- function(obj){
  temp0 <- approx(obj@coverage_data_base1$`number of spots`,obj@coverage_data_base1$`coverage 97.5%`,xout = obj@final_res$new_count)$y  ## compare with the "new_count" which is being corrected
  obj@final_res$new_censored <- (obj@final_res$px_ratio >= temp0)*1
  obj@final_res$new_censored[is.na(obj@final_res$new_censored)] <- 0
  obj@final_res$censored <- obj@final_res$censored + obj@final_res$new_censored

  return(obj)
}

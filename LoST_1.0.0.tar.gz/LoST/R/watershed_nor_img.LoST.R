watershed_nor_img.LoST <- function(obj, tolerance = first_stage_tol){
  ## watershed for segmentation
  for (i in 1:length(obj@img_process)){
    obj@img_process[[i]] <- EBImage::watershed(obj@img_process[[i]],tolerance)
    obj@img_process[[i]] <- EBImage::normalize(obj@img_process[[i]])  ## to normalize the image so that different clusters are more clearly shown when plotting
  }
  return(obj)
}

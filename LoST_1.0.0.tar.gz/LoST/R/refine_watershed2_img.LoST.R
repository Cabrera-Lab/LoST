refine_watershed2_img.LoST <- function(obj, tol0, radius_cv = 0.11, radius_var1 = 1.7, radius_roundness0 = 0.92,px_clus_ratio=0.35){
  # browser()
  for (i in 1:length(obj@img_process)){
    if (length(obj@iso_clus[[i]])==0){
      next
    }
    # record0 = NULL
    width0 = dim(obj@img[[i]])[1]
    height0 = dim(obj@img[[i]])[2]

    count0 = 1
    for (j in 1:length(obj@radius3_var[[i]])){
      if (is.na(obj@radius3_var[[i]][[j]])){
        # obj@iso_clus3[[i]][[j]] = NA
        # obj@clus_center3[[i]][[j]] = NA
        # obj@clus_count3[[i]][[j]] = NA
        # record0 = c(record0,j)
        next
      }
      # if ((obj@radius3_cv[[i]][[j]] > radius_cv && obj@radius3_roundness[[i]][[j]] < radius_roundness0) | obj@radius3_var[[i]][[j]] > radius_var1 | obj@clus_size[[i]][[j]]/obj@base_px[[1]]>px_clus_ratio){
      if (obj@radius3_cv[[i]][[j]] > radius_cv | (obj@radius3_roundness[[i]][[j]] < radius_roundness0 && obj@radius3_var[[i]][[j]] > radius_var1) | (obj@clus_size[[i]][[j]]/obj@base_px[[1]])>px_clus_ratio){

        reconstruct_img <- matrix(data = 0,nrow = width0,ncol = height0)
        reconstruct_img[obj@iso_clus[[i]][[j]]$save_pos0] = obj@iso_clus[[i]][[j]]$save_intensity0

        y <- EBImage::normalize(EBImage::watershed(reconstruct_img,tolerance = tol0)) ## 0.15
        for (jj in unique(as.numeric(y))){
          if (jj==0) next  ## background intensity
          set1 <- which(y == jj,arr.ind = T)
          obj@img_process[[i]][set1] = jj+count0    ## embed the second-stage watershed into "@img_process"
        }
        count0 = count0 + 1

      }
    }
    obj@img_process[[i]] <- EBImage::normalize(obj@img_process[[i]])
  }
  return(obj)
}




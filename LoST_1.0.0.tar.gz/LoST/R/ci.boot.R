#ci.boot: function to get the bootstrap CI for the estimated lambda, i.e., the number of particles in the neat sample, for a sample by JLE with Poisson model.
#data: a vector of a dilution serial count data for a neat sample.
#d: a vector of dilution levels corresponding to each count data.
#p: dilution proportion, i.e, 1/dilution factor
#s: sampling proportion from tubes to wells.
#cen: a positive integer indicating a threshold about censoring. Any counts larger than this integer would be regarded as right-censored.
#nboot: the number of bootstrap samples generated for CI
#level: confidence level for bootstrap CI

ci.boot <- function(data,d,p,s,cen,nboot = 500, level = 0.95){

  if(p <=0 | p >=1){
    stop("dilution proportion p should be between 0 and 1")
  }
  if(s <= 0 | s >= 1){
    stop("sampling proportion s should be between 0 and 1")
  }

  if(cen %% 1 != 0 | cen <= 0){
    stop("cen should be a positive integer")
  }
  if(length(d) != length(data)){
    stop("The length of dilution numbers is not the same as the number of counts.
         The dilution number for each count should be provided.")
  }


  boot_poi = NULL
  est.poi = optimLambda(data,d,p,s,cen)
  for (i in 1:nboot) {
    xrep_poi = gen_rep(est.poi,p,s,max(d),1)
    if (all(xrep_poi==0)){
      boot_poi = c(boot_poi,0)
      next
    }
    boot_poi = c(boot_poi,optimLambda(xrep_poi[d],d,p,s,cen))
  }
  level_l = (1-level)/2
  ci = as.vector(quantile(boot_poi,c(level_l,1-level_l)))

  return(data.frame(bootstrap.CI_L = ci[1],bootstrap.CI_R = ci[2]))
}

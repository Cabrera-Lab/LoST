extreme_case_img.LoST <- function(obj, uncount_px_ratio = 0.32){
  for (i in 1:length(obj@img_process)){
    if (dim(obj@res[[i]])[1]==1 & obj@res[[i]]$number_of_pixels[1]>(prod(dim(obj@img[[i]]))*uncount_px_ratio)){ ## situation that we cannot count, only one huge spot
      print(paste0(names(obj@img)[i]," is not countable."))
      obj@count[[i]] = NA
      obj@completed[[i]] = 1
    } else if (dim(obj@res[[i]])[1]==0){
      obj@count[[i]] = 0
      print(paste0(names(obj@img)[i], ": no cluster found"))
      obj@completed[[i]] = 1
    }
  }
  return(obj)
}






watershed2_nor_img.LoST <- function(obj, tol_vector = c(0.2,0.15,0.1,0.05,0.025),diameter,threshold){
  if (missing(threshold)){
    threshold = pi*(diameter/2)^2/50
    # print("default threshold")
  }
  if (length(obj@iso_clus)==0){

  } else{
    for (i in 1:length(obj@img_process)){
      if (length(obj@iso_clus[[i]])==0){
        next
      }
      count0 = 1
      obj@tolerance1[[i]] = list()
      for ( j in 1:length(obj@iso_clus[[i]])){
        for (k in tol_vector){
          y <- EBImage::normalize(EBImage::watershed(obj@iso_clus[[i]][[j]],tolerance = k))
          if (all(table(y)[-1]<=threshold)){
            # print(paste0(k," ",i))
            break
          }
          # print(paste("search all  ",i))
        }
        obj@tolerance1[[i]][[j]] = k ## record the tolerance for each item in "iso_clus"
        # y <- EBImage::normalize(EBImage::watershed(obj@iso_clus[[i]][[j]],tolerance))

        for (jj in unique(as.numeric(y))){
          if (jj==0) next  ## background intensity
          set1 <- which(y == jj,arr.ind = T)
          obj@img_process[[i]][set1] = jj+count0    ## embed the second-stage watershed into "@img_process"
        }
        count0 = count0 + 1
      }
      obj@img_process[[i]] <- EBImage::normalize(obj@img_process[[i]])
    }
  }
  return(obj)
}
